import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";

export type KnowledgeBase = {
  id: string;
  user_id: string;
  organization_id: string | null;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
};

async function requireUserId() {
  const { data } = await supabase.auth.getUser();
  const id = data.user?.id;
  if (!id) throw new Error("You are signed out.");
  return id;
}

export function useKnowledgeBases() {
  return useQuery<KnowledgeBase[]>({
    queryKey: ["knowledge-bases"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("knowledge_bases")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as KnowledgeBase[];
    },
  });
}

export function useKnowledgeBase(id: string) {
  return useQuery<KnowledgeBase | null>({
    queryKey: ["knowledge-base", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("knowledge_bases")
        .select("*")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return (data as KnowledgeBase) ?? null;
    },
  });
}

export function useCreateKnowledgeBase() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (values: { name: string; description?: string | null }) => {
      const userId = await requireUserId();
      const { data, error } = await supabase
        .from("knowledge_bases")
        .insert({
          user_id: userId,
          name: values.name.trim(),
          description: values.description?.trim() || null,
        })
        .select("*")
        .single();
      if (error) throw error;
      return data as KnowledgeBase;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["knowledge-bases"] });
    },
  });
}

export function useUpdateKnowledgeBase() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (values: { id: string; name: string; description?: string | null }) => {
      const { data, error } = await supabase
        .from("knowledge_bases")
        .update({ name: values.name.trim(), description: values.description?.trim() || null })
        .eq("id", values.id)
        .select("*")
        .single();
      if (error) throw error;
      return data as KnowledgeBase;
    },
    onSuccess: (kb) => {
      queryClient.invalidateQueries({ queryKey: ["knowledge-bases"] });
      queryClient.invalidateQueries({ queryKey: ["knowledge-base", kb.id] });
    },
  });
}

export function useDeleteKnowledgeBase() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("knowledge_bases").delete().eq("id", id);
      if (error) throw error;
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["knowledge-bases"] });
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}
