import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { DOCUMENTS_BUCKET, fileExtension, type DocumentStatus } from "@/lib/documents";

export type DocumentRecord = {
  id: string;
  user_id: string;
  organization_id: string | null;
  knowledge_base_id: string | null;
  title: string;
  description: string | null;
  file_name: string;
  file_path: string;
  file_type: string;
  file_size: number;
  status: DocumentStatus;
  error_message: string | null;
  created_at: string;
  updated_at: string;
};

export type DocumentWithKnowledgeBase = DocumentRecord & {
  knowledge_bases: { id: string; name: string } | null;
};

const SELECT = "*, knowledge_bases(id, name)";

async function requireUserId() {
  const { data } = await supabase.auth.getUser();
  const id = data.user?.id;
  if (!id) throw new Error("You are signed out.");
  return id;
}

export function useDocuments(knowledgeBaseId?: string) {
  return useQuery<DocumentWithKnowledgeBase[]>({
    queryKey: ["documents", knowledgeBaseId ?? "all"],
    queryFn: async () => {
      let query = supabase.from("documents").select(SELECT).order("created_at", { ascending: false });
      if (knowledgeBaseId) query = query.eq("knowledge_base_id", knowledgeBaseId);
      const { data, error } = await query;
      if (error) throw error;
      return (data ?? []) as unknown as DocumentWithKnowledgeBase[];
    },
  });
}

export function useDocument(id: string) {
  return useQuery<DocumentWithKnowledgeBase | null>({
    queryKey: ["document", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("documents").select(SELECT).eq("id", id).maybeSingle();
      if (error) throw error;
      return (data as unknown as DocumentWithKnowledgeBase) ?? null;
    },
  });
}

export type UploadInput = {
  file: File;
  title: string;
  description?: string | null;
  knowledgeBaseId?: string | null;
  onProgress?: (percent: number) => void;
};

export function useUploadDocument() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ file, title, description, knowledgeBaseId, onProgress }: UploadInput) => {
      const userId = await requireUserId();
      const documentId = crypto.randomUUID();
      const ext = fileExtension(file.name);
      const path = `${userId}/${documentId}${ext ? `.${ext}` : ""}`;

      onProgress?.(10);
      const { error: uploadError } = await supabase.storage
        .from(DOCUMENTS_BUCKET)
        .upload(path, file, { contentType: file.type || "application/octet-stream", upsert: false });
      if (uploadError) throw uploadError;
      onProgress?.(70);

      const { data, error } = await supabase
        .from("documents")
        .insert({
          id: documentId,
          user_id: userId,
          title: title.trim() || file.name,
          description: description?.trim() || null,
          knowledge_base_id: knowledgeBaseId || null,
          file_name: file.name,
          file_path: path,
          file_type: file.type || "application/octet-stream",
          file_size: file.size,
          status: "uploaded",
        })
        .select(SELECT)
        .single();

      if (error) {
        // Do not leave an orphaned file behind.
        await supabase.storage.from(DOCUMENTS_BUCKET).remove([path]);
        throw error;
      }
      onProgress?.(90);

      // The file is stored and retrievable, so mark it Ready. No AI processing happens here.
      const { data: ready, error: statusError } = await supabase
        .from("documents")
        .update({ status: "ready" })
        .eq("id", documentId)
        .select(SELECT)
        .single();
      onProgress?.(100);
      if (statusError) return data as unknown as DocumentWithKnowledgeBase;
      return ready as unknown as DocumentWithKnowledgeBase;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}

export function useUpdateDocument() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (values: {
      id: string;
      title?: string;
      description?: string | null;
      knowledgeBaseId?: string | null;
    }) => {
      const patch: {
        title?: string;
        description?: string | null;
        knowledge_base_id?: string | null;
      } = {};
      if (values.title !== undefined) patch.title = values.title.trim();
      if (values.description !== undefined) patch.description = values.description?.trim() || null;
      if (values.knowledgeBaseId !== undefined)
        patch.knowledge_base_id = values.knowledgeBaseId || null;

      const { data, error } = await supabase
        .from("documents")
        .update(patch)
        .eq("id", values.id)
        .select(SELECT)
        .single();
      if (error) throw error;
      return data as unknown as DocumentWithKnowledgeBase;
    },
    onSuccess: (doc) => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
      queryClient.invalidateQueries({ queryKey: ["document", doc.id] });
    },
  });
}

export function useDeleteDocument() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (doc: { id: string; file_path: string }) => {
      const { error: storageError } = await supabase.storage
        .from(DOCUMENTS_BUCKET)
        .remove([doc.file_path]);
      if (storageError) throw storageError;
      const { error } = await supabase.from("documents").delete().eq("id", doc.id);
      if (error) throw error;
      return doc.id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}

/** Short-lived signed URL for a private file. */
export async function createSignedUrl(filePath: string, download = false) {
  const { data, error } = await supabase.storage
    .from(DOCUMENTS_BUCKET)
    .createSignedUrl(filePath, 60 * 5, download ? { download: true } : undefined);
  if (error) throw error;
  return data.signedUrl;
}
