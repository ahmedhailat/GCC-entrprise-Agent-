export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      document_chunks: {
        Row: {
          chunk_index: number
          content: string
          created_at: string
          document_id: string
          embedding: string | null
          id: string
          knowledge_base_id: string | null
          organization_id: string | null
          page_number: number | null
          token_count: number
          user_id: string
        }
        Insert: {
          chunk_index: number
          content: string
          created_at?: string
          document_id: string
          embedding?: string | null
          id?: string
          knowledge_base_id?: string | null
          organization_id?: string | null
          page_number?: number | null
          token_count?: number
          user_id: string
        }
        Update: {
          chunk_index?: number
          content?: string
          created_at?: string
          document_id?: string
          embedding?: string | null
          id?: string
          knowledge_base_id?: string | null
          organization_id?: string | null
          page_number?: number | null
          token_count?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_chunks_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_chunks_knowledge_base_id_fkey"
            columns: ["knowledge_base_id"]
            isOneToOne: false
            referencedRelation: "knowledge_bases"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          created_at: string
          description: string | null
          error_message: string | null
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id: string
          knowledge_base_id: string | null
          organization_id: string | null
          status: Database["public"]["Enums"]["document_status"]
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          error_message?: string | null
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id?: string
          knowledge_base_id?: string | null
          organization_id?: string | null
          status?: Database["public"]["Enums"]["document_status"]
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          error_message?: string | null
          file_name?: string
          file_path?: string
          file_size?: number
          file_type?: string
          id?: string
          knowledge_base_id?: string | null
          organization_id?: string | null
          status?: Database["public"]["Enums"]["document_status"]
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_knowledge_base_id_fkey"
            columns: ["knowledge_base_id"]
            isOneToOne: false
            referencedRelation: "knowledge_bases"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_bases: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          organization_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          name: string
          organization_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          organization_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      processing_jobs: {
        Row: {
          attempt: number
          chunk_count: number
          completed_at: string | null
          created_at: string
          document_id: string
          error_message: string | null
          finished_at: string | null
          id: string
          metadata: Json
          organization_id: string | null
          started_at: string | null
          status: Database["public"]["Enums"]["processing_job_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          attempt?: number
          chunk_count?: number
          completed_at?: string | null
          created_at?: string
          document_id: string
          error_message?: string | null
          finished_at?: string | null
          id?: string
          metadata?: Json
          organization_id?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["processing_job_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          attempt?: number
          chunk_count?: number
          completed_at?: string | null
          created_at?: string
          document_id?: string
          error_message?: string | null
          finished_at?: string | null
          id?: string
          metadata?: Json
          organization_id?: string | null
          started_at?: string | null
          status?: Database["public"]["Enums"]["processing_job_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "processing_jobs_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          company: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          job_title: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          job_title?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          company?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          job_title?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      rate_limit_counters: {
        Row: {
          action: string
          count: number
          user_id: string
          window_start: string
        }
        Insert: {
          action: string
          count?: number
          user_id: string
          window_start: string
        }
        Update: {
          action?: string
          count?: number
          user_id?: string
          window_start?: string
        }
        Relationships: []
      }
      usage_events: {
        Row: {
          chunk_count: number
          conversation_id: string | null
          created_at: string
          document_id: string | null
          error_code: string | null
          error_message: string | null
          estimated_completion_tokens: number
          estimated_prompt_tokens: number
          event_type: string
          id: string
          metadata: Json
          organization_id: string | null
          request_type: string | null
          status: string
          user_id: string
        }
        Insert: {
          chunk_count?: number
          conversation_id?: string | null
          created_at?: string
          document_id?: string | null
          error_code?: string | null
          error_message?: string | null
          estimated_completion_tokens?: number
          estimated_prompt_tokens?: number
          event_type: string
          id?: string
          metadata?: Json
          organization_id?: string | null
          request_type?: string | null
          status?: string
          user_id: string
        }
        Update: {
          chunk_count?: number
          conversation_id?: string | null
          created_at?: string
          document_id?: string | null
          error_code?: string | null
          error_message?: string | null
          estimated_completion_tokens?: number
          estimated_prompt_tokens?: number
          event_type?: string
          id?: string
          metadata?: Json
          organization_id?: string | null
          request_type?: string | null
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "usage_events_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "documents"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      begin_current_user_chunk_replacement: {
        Args: { _document_id: string }
        Returns: undefined
      }
      check_current_user_rate_limit: {
        Args: { _action: string }
        Returns: Json
      }
      check_rate_limit: {
        Args: {
          _action: string
          _limit: number
          _user_id: string
          _window_seconds: number
        }
        Returns: Json
      }
      claim_current_user_document_processing: {
        Args: { _document_id: string }
        Returns: Json
      }
      claim_document_processing: {
        Args: { _document_id: string; _user_id: string }
        Returns: Json
      }
      finish_current_user_document_processing: {
        Args: {
          _chunk_count?: number
          _error_message?: string
          _job_id: string
          _metadata?: Json
          _outcome: string
        }
        Returns: Json
      }
      finish_document_processing: {
        Args: {
          _chunk_count?: number
          _error_message?: string
          _job_id: string
          _outcome: string
          _user_id: string
        }
        Returns: Json
      }
      log_current_user_usage: {
        Args: {
          _chunk_count?: number
          _completion_tokens?: number
          _conversation_id?: string
          _document_id?: string
          _error_code?: string
          _error_message?: string
          _event_type: string
          _metadata?: Json
          _prompt_tokens?: number
          _status?: string
        }
        Returns: string
      }
      log_usage_event: {
        Args: {
          _completion_tokens?: number
          _document_id?: string
          _error_code?: string
          _error_message?: string
          _event_type: string
          _metadata?: Json
          _prompt_tokens?: number
          _status?: string
          _user_id: string
        }
        Returns: string
      }
      match_current_user_document_chunks: {
        Args: {
          _document_id?: string
          _knowledge_base_id?: string
          _match_count?: number
          _query_embedding: string
          _similarity_threshold?: number
        }
        Returns: {
          chunk_id: string
          chunk_index: number
          content: string
          document_id: string
          document_title: string
          file_name: string
          knowledge_base_id: string
          page_number: number
          similarity: number
        }[]
      }
      match_document_chunks: {
        Args: {
          _document_id?: string
          _knowledge_base_id?: string
          _match_count?: number
          _query_embedding: string
          _user_id: string
        }
        Returns: {
          chunk_id: string
          chunk_index: number
          content: string
          document_id: string
          document_title: string
          file_name: string
          knowledge_base_id: string
          page_number: number
          similarity: number
        }[]
      }
      platform_limits: { Args: never; Returns: Json }
      store_current_user_chunk_batch: {
        Args: { _chunks: Json; _document_id: string }
        Returns: number
      }
    }
    Enums: {
      document_status: "uploaded" | "processing" | "ready" | "failed"
      processing_job_status:
        | "queued"
        | "processing"
        | "completed"
        | "failed"
        | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      document_status: ["uploaded", "processing", "ready", "failed"],
      processing_job_status: [
        "queued",
        "processing",
        "completed",
        "failed",
        "cancelled",
      ],
    },
  },
} as const
