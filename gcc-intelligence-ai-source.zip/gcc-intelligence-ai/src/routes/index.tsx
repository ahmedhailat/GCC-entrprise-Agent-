import { createFileRoute } from "@tanstack/react-router";

import { SiteHeader } from "@/components/marketing/SiteHeader";
import { Hero } from "@/components/marketing/Hero";
import { PlatformSection } from "@/components/marketing/PlatformSection";
import { FeatureGrid } from "@/components/marketing/FeatureGrid";
import { SecuritySection } from "@/components/marketing/SecuritySection";
import { IndustriesSection } from "@/components/marketing/IndustriesSection";
import { CallToAction } from "@/components/marketing/CallToAction";
import { SiteFooter } from "@/components/marketing/SiteFooter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GCC Intelligence AI — Enterprise Intelligence for the Gulf" },
      {
        name: "description",
        content:
          "GCC Intelligence AI unifies enterprise documents, conversations and operational knowledge in one secure, governed workspace built for Gulf organisations.",
      },
      {
        property: "og:title",
        content: "GCC Intelligence AI — Enterprise Intelligence for the Gulf",
      },
      {
        property: "og:description",
        content:
          "A secure enterprise workspace with regional data residency, granular access control and audit-ready governance.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LandingPage,
});

function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <PlatformSection />
        <FeatureGrid />
        <SecuritySection />
        <IndustriesSection />
        <CallToAction />
      </main>
      <SiteFooter />
    </div>
  );
}
