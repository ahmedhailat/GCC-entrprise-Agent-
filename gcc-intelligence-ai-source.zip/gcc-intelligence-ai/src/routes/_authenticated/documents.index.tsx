import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { FileText, Search } from "lucide-react";

import { PageHeader } from "@/components/dashboard/PageHeader";
import { DemoBadge } from "@/components/dashboard/DemoBadge";
import { DocumentStatusBadge } from "@/components/documents/DocumentStatusBadge";
import { UploadDocumentDialog } from "@/components/documents/UploadDocumentDialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useDocuments } from "@/hooks/useDocuments";
import { useKnowledgeBases } from "@/hooks/useKnowledgeBases";
import { formatBytes, formatDate, typeLabel } from "@/lib/documents";
import { demoDocuments } from "@/lib/demo-data";

export const Route = createFileRoute("/_authenticated/documents/")({
  head: () => ({
    meta: [
      { title: "Documents — GCC Intelligence AI" },
      {
        name: "description",
        content: "Upload, search and manage your private enterprise document library.",
      },
      { property: "og:title", content: "Documents — GCC Intelligence AI" },
      {
        property: "og:description",
        content: "A secure, searchable library of your organisation's documents.",
      },
    ],
  }),
  component: DocumentsPage,
});

const ALL = "all";

function DocumentsPage() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState(ALL);
  const [knowledgeBaseId, setKnowledgeBaseId] = useState(ALL);
  const [showSamples, setShowSamples] = useState(false);

  const { data: documents, isLoading, isError, error, refetch } = useDocuments();
  const { data: knowledgeBases } = useKnowledgeBases();

  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    return (documents ?? []).filter((doc) => {
      if (status !== ALL && doc.status !== status) return false;
      if (knowledgeBaseId !== ALL) {
        if (knowledgeBaseId === "unassigned" ? doc.knowledge_base_id !== null : doc.knowledge_base_id !== knowledgeBaseId)
          return false;
      }
      if (!term) return true;
      return `${doc.title} ${doc.file_name} ${doc.description ?? ""} ${doc.knowledge_bases?.name ?? ""}`
        .toLowerCase()
        .includes(term);
    });
  }, [documents, query, status, knowledgeBaseId]);

  return (
    <div>
      <PageHeader
        title="Documents"
        description="Your private library. Files are stored securely and only you can open them."
        action={<UploadDocumentDialog />}
      />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative w-full sm:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search documents"
            className="pl-9"
            aria-label="Search documents"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="sm:w-44" aria-label="Filter by status">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All statuses</SelectItem>
            <SelectItem value="uploaded">Uploaded</SelectItem>
            <SelectItem value="processing">Processing</SelectItem>
            <SelectItem value="ready">Ready</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
          </SelectContent>
        </Select>
        <Select value={knowledgeBaseId} onValueChange={setKnowledgeBaseId}>
          <SelectTrigger className="sm:w-56" aria-label="Filter by knowledge base">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All knowledge bases</SelectItem>
            <SelectItem value="unassigned">Unassigned</SelectItem>
            {(knowledgeBases ?? []).map((kb) => (
              <SelectItem key={kb.id} value={kb.id}>
                {kb.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Card className="border-border/70">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="space-y-3 p-6">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : isError ? (
            <div className="p-10 text-center">
              <p className="text-sm text-destructive">
                {error instanceof Error ? error.message : "We could not load your documents."}
              </p>
              <Button variant="outline" className="mt-4" onClick={() => refetch()}>
                Try again
              </Button>
            </div>
          ) : (documents ?? []).length === 0 ? (
            <div className="p-12 text-center">
              <FileText className="mx-auto size-8 text-muted-foreground" />
              <p className="mt-4 text-sm font-medium">No documents yet</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Upload a PDF, CSV or text file to start your library.
              </p>
              <div className="mt-5 flex justify-center">
                <UploadDocumentDialog />
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Title</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Knowledge base</TableHead>
                    <TableHead>Size</TableHead>
                    <TableHead>Uploaded</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((doc) => (
                    <TableRow key={doc.id} className="cursor-pointer">
                      <TableCell className="font-medium">
                        <Link
                          to="/documents/$documentId"
                          params={{ documentId: doc.id }}
                          className="hover:text-primary"
                        >
                          {doc.title}
                        </Link>
                        <span className="block text-xs text-muted-foreground">{doc.file_name}</span>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {typeLabel(doc.file_type, doc.file_name)}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {doc.knowledge_bases?.name ?? "Unassigned"}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatBytes(doc.file_size)}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(doc.created_at)}
                      </TableCell>
                      <TableCell>
                        <DocumentStatusBadge status={doc.status} />
                      </TableCell>
                    </TableRow>
                  ))}
                  {filtered.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={6} className="py-10 text-center text-muted-foreground">
                        No documents match your filters.
                      </TableCell>
                    </TableRow>
                  ) : null}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="mt-10">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-medium text-muted-foreground">Sample library</h2>
            <DemoBadge />
          </div>
          <Button variant="ghost" size="sm" onClick={() => setShowSamples((v) => !v)}>
            {showSamples ? "Hide" : "Show"}
          </Button>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">
          Illustrative entries from the Phase 1 preview. They are kept separate from your real
          uploads above.
        </p>
        {showSamples ? (
          <Card className="mt-4 border-dashed border-border/70">
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Owner</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Updated</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {demoDocuments.map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell className="font-medium text-muted-foreground">
                          {doc.name}
                        </TableCell>
                        <TableCell className="text-muted-foreground">{doc.category}</TableCell>
                        <TableCell className="text-muted-foreground">{doc.owner}</TableCell>
                        <TableCell className="text-muted-foreground">{doc.size}</TableCell>
                        <TableCell className="text-muted-foreground">{doc.updated}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        ) : null}
      </div>
    </div>
  );
}
