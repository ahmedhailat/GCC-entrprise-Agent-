import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Library, Plus } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/dashboard/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useDocuments } from "@/hooks/useDocuments";
import { useCreateKnowledgeBase, useKnowledgeBases } from "@/hooks/useKnowledgeBases";
import { formatDate } from "@/lib/documents";

export const Route = createFileRoute("/_authenticated/knowledge-bases/")({
  head: () => ({
    meta: [
      { title: "Knowledge bases — GCC Intelligence AI" },
      {
        name: "description",
        content: "Group your documents into named knowledge bases for each business area.",
      },
      { property: "og:title", content: "Knowledge bases — GCC Intelligence AI" },
      {
        property: "og:description",
        content: "Organise your secure document library into knowledge bases.",
      },
    ],
  }),
  component: KnowledgeBasesPage,
});

export function CreateKnowledgeBaseDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const create = useCreateKnowledgeBase();

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    try {
      await create.mutateAsync({ name, description });
      toast.success("Knowledge base created");
      setName("");
      setDescription("");
      setOpen(false);
    } catch (err) {
      toast.error("Could not create knowledge base", {
        description: err instanceof Error ? err.message : undefined,
      });
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="size-4" />
          New knowledge base
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>New knowledge base</DialogTitle>
          <DialogDescription>
            Give it a clear name so you can assign documents to it later.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="kb-name">Name</Label>
            <Input
              id="kb-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Finance policies"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="kb-description">Description (optional)</Label>
            <Textarea
              id="kb-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={create.isPending}>
              {create.isPending ? "Creating…" : "Create"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function KnowledgeBasesPage() {
  const { data: knowledgeBases, isLoading, isError, error, refetch } = useKnowledgeBases();
  const { data: documents } = useDocuments();

  const countFor = (id: string) =>
    (documents ?? []).filter((doc) => doc.knowledge_base_id === id).length;

  return (
    <div>
      <PageHeader
        title="Knowledge bases"
        description="Group related documents so each business area has its own collection."
        action={<CreateKnowledgeBaseDialog />}
      />

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-36 w-full" />
          ))}
        </div>
      ) : isError ? (
        <div className="py-16 text-center">
          <p className="text-sm text-destructive">
            {error instanceof Error ? error.message : "We could not load your knowledge bases."}
          </p>
          <Button variant="outline" className="mt-4" onClick={() => refetch()}>
            Try again
          </Button>
        </div>
      ) : (knowledgeBases ?? []).length === 0 ? (
        <Card className="border-dashed border-border/70">
          <CardContent className="p-12 text-center">
            <Library className="mx-auto size-8 text-muted-foreground" />
            <p className="mt-4 text-sm font-medium">No knowledge bases yet</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Create one to organise your documents by team, project or policy area.
            </p>
            <div className="mt-5 flex justify-center">
              <CreateKnowledgeBaseDialog />
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {(knowledgeBases ?? []).map((kb) => (
            <Link
              key={kb.id}
              to="/knowledge-bases/$knowledgeBaseId"
              params={{ knowledgeBaseId: kb.id }}
              className="rounded-xl transition-colors"
            >
              <Card className="h-full border-border/70 hover:border-primary/40">
                <CardHeader>
                  <CardTitle className="text-base">{kb.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <p className="line-clamp-2 text-muted-foreground">
                    {kb.description || "No description."}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {countFor(kb.id)} document{countFor(kb.id) === 1 ? "" : "s"} · created{" "}
                    {formatDate(kb.created_at)}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
