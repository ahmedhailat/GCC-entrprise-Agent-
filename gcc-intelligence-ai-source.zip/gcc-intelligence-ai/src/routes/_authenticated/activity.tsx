import { createFileRoute } from "@tanstack/react-router";

import { PageHeader } from "@/components/dashboard/PageHeader";
import { DemoNotice } from "@/components/dashboard/DemoBadge";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { Card, CardContent } from "@/components/ui/card";
import { demoActivity } from "@/lib/demo-data";

export const Route = createFileRoute("/_authenticated/activity")({
  head: () => ({
    meta: [
      { title: "Activity — GCC Intelligence AI" },
      {
        name: "description",
        content: "An audit-style timeline of events across your GCC Intelligence AI workspace.",
      },
      { property: "og:title", content: "Activity — GCC Intelligence AI" },
      {
        property: "og:description",
        content: "Review recent document, conversation and security events in your workspace.",
      },
    ],
  }),
  component: ActivityPage,
});

function ActivityPage() {
  return (
    <div>
      <PageHeader
        title="Activity"
        description="An audit-style timeline of everything happening in your workspace."
      />
      <DemoNotice>
        This timeline shows sample events so you can review the layout before live tracking is
        connected.
      </DemoNotice>
      <Card className="border-border/70">
        <CardContent className="pt-6">
          <ActivityFeed items={demoActivity} />
        </CardContent>
      </Card>
    </div>
  );
}
