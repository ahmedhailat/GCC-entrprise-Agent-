import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, FileText, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/dashboard/PageHeader";
import { DocumentStatusBadge } from "@/components/documents/DocumentStatusBadge";
import { UploadDocumentDialog } from "@/components/documents/UploadDocumentDialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useDocuments } from "@/hooks/useDocuments";
import {
  useDeleteKnowledgeBase,
  useKnowledgeBase,
  useUpdateKnowledgeBase,
} from "@/hooks/useKnowledgeBases";
import { formatBytes, formatDate, typeLabel } from "@/lib/documents";

export const Route = createFileRoute("/_authenticated/knowledge-bases/$knowledgeBaseId")({
  head: () => ({
    meta: [
      { title: "Knowledge base — GCC Intelligence AI" },
      {
        name: "description",
        content: "Review a knowledge base and the documents assigned to it.",
      },
      { property: "og:title", content: "Knowledge base — GCC Intelligence AI" },
      {
        property: "og:description",
        content: "Manage a knowledge base and its assigned documents.",
      },
    ],
  }),
  component: KnowledgeBaseDetailsPage,
});

function KnowledgeBaseDetailsPage() {
  const { knowledgeBaseId } = Route.useParams();
  const navigate = useNavigate();
  const { data: kb, isLoading, isError, error } = useKnowledgeBase(knowledgeBaseId);
  const { data: documents, isLoading: documentsLoading } = useDocuments(knowledgeBaseId);
  const update = useUpdateKnowledgeBase();
  const remove = useDeleteKnowledgeBase();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");

  useEffect(() => {
    if (!kb) return;
    setName(kb.name);
    setDescription(kb.description ?? "");
  }, [kb]);

  async function handleSave(event: React.FormEvent) {
    event.preventDefault();
    if (!kb) return;
    try {
      await update.mutateAsync({ id: kb.id, name, description });
      toast.success("Knowledge base updated");
    } catch (err) {
      toast.error("Could not save changes", {
        description: err instanceof Error ? err.message : undefined,
      });
    }
  }

  async function handleDelete() {
    if (!kb) return;
    try {
      await remove.mutateAsync(kb.id);
      toast.success("Knowledge base deleted", {
        description: "Its documents are kept and are now unassigned.",
      });
      navigate({ to: "/knowledge-bases" });
    } catch (err) {
      toast.error("Could not delete this knowledge base", {
        description: err instanceof Error ? err.message : undefined,
      });
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (isError || !kb) {
    return (
      <div className="py-16 text-center">
        <p className="text-sm text-muted-foreground">
          {error instanceof Error ? error.message : "This knowledge base could not be found."}
        </p>
        <Button variant="outline" className="mt-4" asChild>
          <Link to="/knowledge-bases">Back to knowledge bases</Link>
        </Button>
      </div>
    );
  }

  return (
    <div>
      <Button variant="ghost" size="sm" className="mb-4 -ml-2 text-muted-foreground" asChild>
        <Link to="/knowledge-bases">
          <ArrowLeft className="size-4" />
          Knowledge bases
        </Link>
      </Button>

      <PageHeader
        title={kb.name}
        description={kb.description || "No description."}
        action={
          <div className="flex gap-2">
            <UploadDocumentDialog defaultKnowledgeBaseId={kb.id} lockKnowledgeBase />
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" className="text-destructive">
                  <Trash2 className="size-4" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this knowledge base?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Its documents are kept in your library and become unassigned.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} disabled={remove.isPending}>
                    {remove.isPending ? "Deleting…" : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="border-border/70 lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Edit</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSave} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="kb-edit-name">Name</Label>
                <Input
                  id="kb-edit-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="kb-edit-description">Description</Label>
                <Textarea
                  id="kb-edit-description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                />
              </div>
              <Button type="submit" disabled={update.isPending}>
                {update.isPending ? "Saving…" : "Save changes"}
              </Button>
              <p className="text-xs text-muted-foreground">Created {formatDate(kb.created_at)}</p>
            </form>
          </CardContent>
        </Card>

        <Card className="border-border/70 lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Assigned documents</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {documentsLoading ? (
              <div className="space-y-3 p-6">
                {[0, 1].map((i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : (documents ?? []).length === 0 ? (
              <div className="p-12 text-center">
                <FileText className="mx-auto size-8 text-muted-foreground" />
                <p className="mt-4 text-sm font-medium">No documents assigned yet</p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Upload a file here, or assign an existing document from its details page.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(documents ?? []).map((doc) => (
                      <TableRow key={doc.id}>
                        <TableCell className="font-medium">
                          <Link
                            to="/documents/$documentId"
                            params={{ documentId: doc.id }}
                            className="hover:text-primary"
                          >
                            {doc.title}
                          </Link>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {typeLabel(doc.file_type, doc.file_name)}
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatBytes(doc.file_size)}
                        </TableCell>
                        <TableCell>
                          <DocumentStatusBadge status={doc.status} />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
