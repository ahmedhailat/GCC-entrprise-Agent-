import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

import { PageHeader } from "@/components/dashboard/PageHeader";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { initialsFrom, useProfile, useUpdateProfile } from "@/hooks/useProfile";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Profile — GCC Intelligence AI" },
      {
        name: "description",
        content: "Manage your name, company, role and profile photo in GCC Intelligence AI.",
      },
      { property: "og:title", content: "Profile — GCC Intelligence AI" },
      {
        property: "og:description",
        content: "Update your workspace account details.",
      },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const { data: profile, isLoading } = useProfile();
  const updateProfile = useUpdateProfile();

  const [fullName, setFullName] = useState("");
  const [company, setCompany] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");

  useEffect(() => {
    if (!profile) return;
    setFullName(profile.full_name ?? "");
    setCompany(profile.company ?? "");
    setJobTitle(profile.job_title ?? "");
    setAvatarUrl(profile.avatar_url ?? "");
  }, [profile]);

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    try {
      await updateProfile.mutateAsync({
        full_name: fullName.trim() || null,
        company: company.trim() || null,
        job_title: jobTitle.trim() || null,
        avatar_url: avatarUrl.trim() || null,
      });
      toast.success("Profile updated");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save your profile.");
    }
  }

  return (
    <div className="max-w-3xl">
      <PageHeader title="Profile" description="Your identity across the workspace." />

      {isLoading ? (
        <div className="flex h-40 items-center justify-center">
          <Loader2 className="size-5 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <Card className="border-border/70">
          <CardHeader>
            <CardTitle className="text-base">Account details</CardTitle>
            <CardDescription>
              Your email address is managed by sign-in and cannot be changed here.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-8 flex items-center gap-4">
              <Avatar className="size-16">
                {avatarUrl ? <AvatarImage src={avatarUrl} alt="Profile photo" /> : null}
                <AvatarFallback className="bg-primary/15 text-primary">
                  {initialsFrom(fullName, profile?.email)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium">{fullName || "Your account"}</p>
                <p className="text-sm text-muted-foreground">{profile?.email}</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="grid gap-5 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="full-name">Full name</Label>
                <Input
                  id="full-name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Layla Al Mansouri"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" value={profile?.email ?? ""} disabled readOnly />
              </div>
              <div className="space-y-2">
                <Label htmlFor="company">Company</Label>
                <Input
                  id="company"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="Example Holding Group"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="job-title">Job title</Label>
                <Input
                  id="job-title"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  placeholder="Head of Compliance"
                />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="avatar-url">Profile photo link</Label>
                <Input
                  id="avatar-url"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="https://…"
                />
              </div>
              <div className="sm:col-span-2">
                <Button type="submit" disabled={updateProfile.isPending}>
                  {updateProfile.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
                  Save changes
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
