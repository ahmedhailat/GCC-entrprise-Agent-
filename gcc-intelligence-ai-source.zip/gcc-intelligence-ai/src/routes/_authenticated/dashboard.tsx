import { createFileRoute } from "@tanstack/react-router";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

import { PageHeader } from "@/components/dashboard/PageHeader";
import { DemoBadge, DemoNotice } from "@/components/dashboard/DemoBadge";
import { ActivityFeed } from "@/components/dashboard/ActivityFeed";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { demoActivity, demoMetrics, demoUsage } from "@/lib/demo-data";
import { useProfile } from "@/hooks/useProfile";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Workspace overview — GCC Intelligence AI" },
      {
        name: "description",
        content: "Executive overview of your GCC Intelligence AI enterprise workspace.",
      },
      { property: "og:title", content: "Workspace overview — GCC Intelligence AI" },
      {
        property: "og:description",
        content: "Metrics, usage trends and recent activity across your workspace.",
      },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { data: profile } = useProfile();
  const firstName = profile?.full_name?.split(" ")[0];

  return (
    <div>
      <PageHeader
        title={firstName ? `Welcome back, ${firstName}` : "Workspace overview"}
        description="A consolidated view of your enterprise workspace."
      />

      <DemoNotice>
        The figures, charts and entries below are sample content used to illustrate the workspace
        layout. Live data arrives in Phase 2.
      </DemoNotice>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {demoMetrics.map((metric) => (
          <Card key={metric.id} className="border-border/70">
            <CardHeader className="pb-2">
              <CardTitle className="text-xs font-medium uppercase tracking-[0.12em] text-muted-foreground">
                {metric.label}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between">
                <span className="font-display text-3xl font-semibold">{metric.value}</span>
                <span
                  className={
                    metric.trend === "up"
                      ? "inline-flex items-center gap-1 text-xs text-success"
                      : "inline-flex items-center gap-1 text-xs text-destructive"
                  }
                >
                  {metric.trend === "up" ? (
                    <ArrowUpRight className="size-3.5" />
                  ) : (
                    <ArrowDownRight className="size-3.5" />
                  )}
                  {metric.change}
                </span>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">{metric.hint}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Card className="border-border/70 lg:col-span-3">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Workspace usage</CardTitle>
            <DemoBadge />
          </CardHeader>
          <CardContent className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={demoUsage} margin={{ left: -20, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="docsFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="queriesFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--chart-2)" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="var(--chart-2)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis
                  dataKey="month"
                  stroke="var(--muted-foreground)"
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                />
                <YAxis
                  stroke="var(--muted-foreground)"
                  tickLine={false}
                  axisLine={false}
                  fontSize={12}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--popover)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.5rem",
                    color: "var(--popover-foreground)",
                    fontSize: 12,
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="documents"
                  stroke="var(--chart-1)"
                  fill="url(#docsFill)"
                  strokeWidth={2}
                />
                <Area
                  type="monotone"
                  dataKey="queries"
                  stroke="var(--chart-2)"
                  fill="url(#queriesFill)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/70 lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Recent activity</CardTitle>
            <DemoBadge />
          </CardHeader>
          <CardContent>
            <ActivityFeed items={demoActivity.slice(0, 4)} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
