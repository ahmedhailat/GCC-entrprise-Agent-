import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Download, ExternalLink, Sparkles, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { processDocument as processDocumentFn } from "@/lib/ai/ai.functions";
import { toast } from "sonner";

import { PageHeader } from "@/components/dashboard/PageHeader";
import { DocumentStatusBadge } from "@/components/documents/DocumentStatusBadge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  createSignedUrl,
  useDeleteDocument,
  useDocument,
  useUpdateDocument,
} from "@/hooks/useDocuments";
import { useKnowledgeBases } from "@/hooks/useKnowledgeBases";
import {
  STATUS_META,
  formatBytes,
  formatDate,
  isInlinePreviewable,
  typeLabel,
} from "@/lib/documents";

export const Route = createFileRoute("/_authenticated/documents/$documentId")({
  head: () => ({
    meta: [
      { title: "Document details — GCC Intelligence AI" },
      {
        name: "description",
        content: "Review document metadata, preview the file and manage its knowledge base.",
      },
      { property: "og:title", content: "Document details — GCC Intelligence AI" },
      {
        property: "og:description",
        content: "Metadata, secure preview and management for a single document.",
      },
    ],
  }),
  component: DocumentDetailsPage,
});

const NONE = "none";

function DocumentDetailsPage() {
  const { documentId } = Route.useParams();
  const navigate = useNavigate();
  const { data: doc, isLoading, isError, error } = useDocument(documentId);
  const { data: knowledgeBases } = useKnowledgeBases();
  const update = useUpdateDocument();
  const remove = useDeleteDocument();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [knowledgeBaseId, setKnowledgeBaseId] = useState(NONE);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const queryClient = useQueryClient();
  const processDocument = useServerFn(processDocumentFn);

  useEffect(() => {
    if (!doc) return;
    setTitle(doc.title);
    setDescription(doc.description ?? "");
    setKnowledgeBaseId(doc.knowledge_base_id ?? NONE);
    if (isInlinePreviewable(doc.file_name)) {
      createSignedUrl(doc.file_path)
        .then(setPreviewUrl)
        .catch(() => setPreviewUrl(null));
    } else {
      setPreviewUrl(null);
    }
  }, [doc]);

  async function handleProcess() {
    if (!doc) return;
    setProcessing(true);
    try {
      const result = await processDocument({ data: { documentId: doc.id } });
      if (result.ok) {
        toast.success(`Processed into ${result.chunkCount} passages`);
      } else {
        toast.error("Processing did not complete", {
          description: result.message ?? result.code.replace(/_/g, " "),
        });
      }
    } catch (err) {
      toast.error("Processing failed", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setProcessing(false);
      queryClient.invalidateQueries();
    }
  }

  async function handleDownload() {
    if (!doc) return;
    try {
      const url = await createSignedUrl(doc.file_path, true);
      window.open(url, "_blank", "noopener");
    } catch {
      toast.error("We could not open this file right now.");
    }
  }

  async function handleSave(event: React.FormEvent) {
    event.preventDefault();
    if (!doc) return;
    try {
      await update.mutateAsync({
        id: doc.id,
        title,
        description,
        knowledgeBaseId: knowledgeBaseId === NONE ? null : knowledgeBaseId,
      });
      toast.success("Document updated");
    } catch (err) {
      toast.error("Could not save changes", {
        description: err instanceof Error ? err.message : undefined,
      });
    }
  }

  async function handleDelete() {
    if (!doc) return;
    try {
      await remove.mutateAsync({ id: doc.id, file_path: doc.file_path });
      toast.success("Document deleted");
      navigate({ to: "/documents" });
    } catch (err) {
      toast.error("Could not delete this document", {
        description: err instanceof Error ? err.message : undefined,
      });
    }
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  if (isError || !doc) {
    return (
      <div className="py-16 text-center">
        <p className="text-sm text-muted-foreground">
          {error instanceof Error ? error.message : "This document could not be found."}
        </p>
        <Button variant="outline" className="mt-4" asChild>
          <Link to="/documents">Back to documents</Link>
        </Button>
      </div>
    );
  }

  return (
    <div>
      <Button variant="ghost" size="sm" className="mb-4 -ml-2 text-muted-foreground" asChild>
        <Link to="/documents">
          <ArrowLeft className="size-4" />
          Documents
        </Link>
      </Button>

      <PageHeader
        title={doc.title}
        description={doc.file_name}
        action={
          <div className="flex gap-2">
            <Button onClick={handleProcess} disabled={processing || doc.status === "processing"}>
              <Sparkles className="size-4" />
              {processing ? "Processing…" : "Process"}
            </Button>
            <Button variant="outline" onClick={handleDownload}>
              <Download className="size-4" />
              Download
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" className="text-destructive">
                  <Trash2 className="size-4" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete this document?</AlertDialogTitle>
                  <AlertDialogDescription>
                    The file and its record are permanently removed. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} disabled={remove.isPending}>
                    {remove.isPending ? "Deleting…" : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="border-border/70 lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-base">Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <Detail label="Status">
              <div className="flex items-center gap-2">
                <DocumentStatusBadge status={doc.status} />
                <span className="text-xs text-muted-foreground">
                  {STATUS_META[doc.status].description}
                </span>
              </div>
            </Detail>
            <Detail label="Type">{typeLabel(doc.file_type, doc.file_name)}</Detail>
            <Detail label="Size">{formatBytes(doc.file_size)}</Detail>
            <Detail label="Knowledge base">
              {doc.knowledge_bases ? (
                <Link
                  to="/knowledge-bases/$knowledgeBaseId"
                  params={{ knowledgeBaseId: doc.knowledge_bases.id }}
                  className="text-primary hover:underline"
                >
                  {doc.knowledge_bases.name}
                </Link>
              ) : (
                "Unassigned"
              )}
            </Detail>
            <Detail label="Uploaded">{formatDate(doc.created_at)}</Detail>
            <Detail label="Last updated">{formatDate(doc.updated_at)}</Detail>
            {doc.error_message ? (
              <Detail label="Error">
                <span className="text-destructive">{doc.error_message}</span>
              </Detail>
            ) : null}
          </CardContent>
        </Card>

        <div className="space-y-6 lg:col-span-2">
          <Card className="border-border/70">
            <CardHeader>
              <CardTitle className="text-base">Edit</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSave} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-title">Title</Label>
                  <Input
                    id="edit-title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-description">Description</Label>
                  <Textarea
                    id="edit-description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-kb">Knowledge base</Label>
                  <Select value={knowledgeBaseId} onValueChange={setKnowledgeBaseId}>
                    <SelectTrigger id="edit-kb">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NONE}>Unassigned</SelectItem>
                      {(knowledgeBases ?? []).map((kb) => (
                        <SelectItem key={kb.id} value={kb.id}>
                          {kb.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" disabled={update.isPending}>
                  {update.isPending ? "Saving…" : "Save changes"}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="border-border/70">
            <CardHeader>
              <CardTitle className="text-base">Preview</CardTitle>
            </CardHeader>
            <CardContent>
              {previewUrl ? (
                <div className="space-y-3">
                  <iframe
                    src={previewUrl}
                    title={`Preview of ${doc.file_name}`}
                    className="h-[480px] w-full rounded-lg border border-border bg-card"
                  />
                  <Button variant="outline" size="sm" asChild>
                    <a href={previewUrl} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="size-4" />
                      Open in a new tab
                    </a>
                  </Button>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  In-browser preview is available for PDF, CSV and text files. Download this file to
                  open it in its own application.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Detail({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">{label}</p>
      <div className="mt-1">{children}</div>
    </div>
  );
}
