/**
 * Phase 2 — real document management constants and helpers.
 * Files live in the private `documents` storage bucket under `<user_id>/<document_id>.<ext>`.
 */

export const DOCUMENTS_BUCKET = "documents";

export const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25 MB

export type AllowedType = {
  extension: string;
  mimeTypes: string[];
  label: string;
};

export const ALLOWED_TYPES: AllowedType[] = [
  { extension: "pdf", mimeTypes: ["application/pdf"], label: "PDF" },
  {
    extension: "docx",
    mimeTypes: ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
    label: "Word",
  },
  {
    extension: "xlsx",
    mimeTypes: ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
    label: "Excel",
  },
  { extension: "csv", mimeTypes: ["text/csv", "application/csv"], label: "CSV" },
  { extension: "txt", mimeTypes: ["text/plain"], label: "Text" },
];

/** Only types with a real text-extraction engine can be uploaded. Word/Excel stay labelled for older files. */
export const UPLOADABLE_EXTENSIONS = ["pdf", "csv", "txt"];
export const ACCEPT_ATTRIBUTE = ".pdf,.csv,.txt";

export function fileExtension(name: string) {
  const parts = name.split(".");
  return parts.length > 1 ? (parts.pop() ?? "").toLowerCase() : "";
}

export function typeLabel(fileType: string, fileName?: string) {
  const byMime = ALLOWED_TYPES.find((t) => t.mimeTypes.includes(fileType));
  if (byMime) return byMime.label;
  const ext = fileName ? fileExtension(fileName) : "";
  return ALLOWED_TYPES.find((t) => t.extension === ext)?.label ?? "File";
}

/** Returns an error message when the file is not acceptable, otherwise null. */
export function validateFile(file: File): string | null {
  const ext = fileExtension(file.name);
  if (!UPLOADABLE_EXTENSIONS.includes(ext)) {
    return "Unsupported file type. Please upload a PDF, CSV or TXT file.";
  }
  if (file.size === 0) return "This file is empty.";
  if (file.size > MAX_FILE_SIZE) {
    return `File is too large. The maximum size is ${formatBytes(MAX_FILE_SIZE)}.`;
  }
  return null;
}

export function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  const units = ["KB", "MB", "GB"];
  let value = bytes / 1024;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(value >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

export function formatDate(iso: string) {
  return new Date(iso).toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** File types the browser can safely show inline from a signed URL. */
export function isInlinePreviewable(fileName: string) {
  const ext = fileExtension(fileName);
  return ext === "pdf" || ext === "txt" || ext === "csv";
}

export const STATUS_META = {
  uploaded: { label: "Uploaded", description: "Stored securely in your workspace." },
  processing: { label: "Processing", description: "Being prepared." },
  ready: { label: "Ready", description: "Stored and available to open or download." },
  failed: { label: "Failed", description: "Something went wrong with this upload." },
} as const;

export type DocumentStatus = keyof typeof STATUS_META;
