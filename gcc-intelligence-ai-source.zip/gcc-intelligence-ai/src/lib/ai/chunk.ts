/**
 * Deterministic text chunking with overlap.
 * Pure and side-effect free so it can be unit-tested and reasoned about.
 */
import { PLATFORM_LIMITS, estimateTokens } from "@/lib/ai/limits";

export const CHUNK_SIZE_CHARS = 1200;
export const CHUNK_OVERLAP_CHARS = 200;

export type ExtractedPage = { pageNumber: number | null; text: string };

export type Chunk = {
  chunkIndex: number;
  content: string;
  pageNumber: number | null;
  tokenCount: number;
};

function normalize(text: string) {
  return text
    .replace(/\r\n?/g, "\n")
    .replace(/\u0000/g, "")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** Split one page of text into overlapping windows, preferring sentence/paragraph breaks. */
function splitPage(text: string): string[] {
  const clean = normalize(text);
  if (!clean) return [];
  if (clean.length <= CHUNK_SIZE_CHARS) return [clean];

  const out: string[] = [];
  let start = 0;
  while (start < clean.length) {
    let end = Math.min(start + CHUNK_SIZE_CHARS, clean.length);
    if (end < clean.length) {
      const window = clean.slice(start, end);
      const breakAt = Math.max(
        window.lastIndexOf("\n\n"),
        window.lastIndexOf(". "),
        window.lastIndexOf("\n"),
      );
      // Only honour a break point in the last third, so chunks stay a sensible size.
      if (breakAt > CHUNK_SIZE_CHARS * 0.6) end = start + breakAt + 1;
    }
    const piece = clean.slice(start, end).trim();
    if (piece) out.push(piece);
    if (end >= clean.length) break;
    start = Math.max(end - CHUNK_OVERLAP_CHARS, start + 1);
  }
  return out;
}

export type ChunkResult = {
  chunks: Chunk[];
  /** True when the chunk cap stopped us before the end of the document. */
  truncated: boolean;
};

export function chunkPages(pages: ExtractedPage[]): ChunkResult {
  const chunks: Chunk[] = [];
  let truncated = false;

  for (const page of pages) {
    for (const piece of splitPage(page.text)) {
      if (chunks.length >= PLATFORM_LIMITS.maxChunksPerDocument) {
        truncated = true;
        return { chunks, truncated };
      }
      chunks.push({
        chunkIndex: chunks.length,
        content: piece,
        pageNumber: page.pageNumber,
        tokenCount: estimateTokens(piece),
      });
    }
  }

  return { chunks, truncated };
}
