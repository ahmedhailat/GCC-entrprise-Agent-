/**
 * Platform usage limits. These mirror `public.platform_limits()` in the database,
 * which is the authoritative source for limits enforced inside SQL functions/triggers.
 * Keep both in sync when changing a value.
 */
export const PLATFORM_LIMITS = {
  /** Largest file accepted for upload (bucket limit + documents CHECK constraint). */
  maxUploadBytes: 25 * 1024 * 1024,
  /** Largest document that may be sent for (future) processing. */
  maxProcessingBytes: 10 * 1024 * 1024,
  /** Hard cap on chunks per document (trigger-enforced). */
  maxChunksPerDocument: 500,
  /** Hard cap on retrieved chunks per RAG request (server-enforced). */
  maxRetrievedChunks: 8,
  /** Rate limits (DB-enforced fixed windows). */
  processDocumentPerHour: 20,
  ragChatPerMinute: 10,
  ragChatPerDay: 300,
  /** Longest chat message accepted. */
  maxChatMessageChars: 4000,
} as const;

/**
 * File types that can currently be read and indexed for search.
 * DOCX/XLSX remain uploadable but are not advertised as processable.
 */
export const PROCESSABLE_EXTENSIONS = ["pdf", "txt", "csv"] as const;
export type ProcessableExtension = (typeof PROCESSABLE_EXTENSIONS)[number];

export function isProcessableFileName(fileName: string) {
  const ext = (fileName.split(".").pop() ?? "").toLowerCase();
  return (PROCESSABLE_EXTENSIONS as readonly string[]).includes(ext);
}

/** Rough token estimate used for usage accounting before any model is called. */
export function estimateTokens(text: string) {
  return Math.ceil(text.length / 4);
}
