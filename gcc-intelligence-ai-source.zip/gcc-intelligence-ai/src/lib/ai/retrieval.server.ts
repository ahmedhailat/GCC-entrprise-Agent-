/**
 * Server-only retrieval helpers. The owner-scoped similarity search lives in the
 * database (`public.match_current_user_document_chunks`) and derives identity from
 * the authenticated database session, so user and organization ids cannot be spoofed.
 */
import type { SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "@/integrations/supabase/types";
import type { Chunk } from "@/lib/ai/chunk";
import { PLATFORM_LIMITS } from "@/lib/ai/limits";

export type MatchedChunk = {
  chunk_id: string;
  document_id: string;
  knowledge_base_id: string | null;
  chunk_index: number;
  page_number: number | null;
  content: string;
  file_name: string;
  document_title: string;
  similarity: number;
};

export async function matchChunks(params: {
  userClient: SupabaseClient<Database>;
  queryEmbedding: number[];
  knowledgeBaseId: string | null;
  documentId: string | null;
  matchCount: number;
  similarityThreshold?: number;
}): Promise<MatchedChunk[]> {
  const { data, error } = await params.userClient.rpc("match_current_user_document_chunks", {
    _query_embedding: JSON.stringify(params.queryEmbedding),
    ...(params.knowledgeBaseId ? { _knowledge_base_id: params.knowledgeBaseId } : {}),
    ...(params.documentId ? { _document_id: params.documentId } : {}),
    _match_count: Math.min(params.matchCount, PLATFORM_LIMITS.maxRetrievedChunks),
    _similarity_threshold: params.similarityThreshold ?? 0.2,
  });
  if (error) throw new Error(`retrieval failed: ${error.message}`);
  return (data ?? []) as unknown as MatchedChunk[];
}

/** Replaces all stored passages for a document with a freshly generated set. */
export async function replaceChunks(
  userClient: SupabaseClient<Database>,
  documentId: string,
  chunks: Chunk[],
  embeddings: number[][],
) {
  const cleared = await userClient.rpc("begin_current_user_chunk_replacement", { _document_id: documentId });
  if (cleared.error) throw new Error(`could not clear old chunks: ${cleared.error.message}`);

  // Field names match public.store_current_user_chunk_batch; embedding is a real array
  // that the database casts to vector(1536).
  const rows = chunks.map((chunk, i) => ({
    chunkIndex: chunk.chunkIndex,
    content: chunk.content,
    pageNumber: chunk.pageNumber,
    tokenCount: chunk.tokenCount,
    embedding: embeddings[i],
  }));

  // Insert in batches so a large document does not exceed request limits.
  const BATCH = 50;
  for (let i = 0; i < rows.length; i += BATCH) {
    const { error } = await userClient.rpc("store_current_user_chunk_batch", {
      _document_id: documentId,
      _chunks: rows.slice(i, i + BATCH) as never,
    });
    if (error) throw new Error(`could not store chunks: ${error.message}`);
  }
  return rows.length;
}

export async function downloadDocumentFile(userClient: SupabaseClient<Database>, filePath: string) {
  const { data, error } = await userClient.storage.from("documents").download(filePath);
  if (error || !data) throw new Error(`could not read the stored file: ${error?.message ?? "missing"}`);
  return new Uint8Array(await data.arrayBuffer());
}
