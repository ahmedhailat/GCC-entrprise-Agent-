/**
 * Server-only security guards for AI endpoints.
 * Never imported by client code (blocked by the *.server.ts import rule).
 *
 * All state lives in the database. Every callable function derives auth.uid() from
 * the verified request session; browser input never supplies a user or organization id.
 */
import type { SupabaseClient } from "@supabase/supabase-js";

import type { Database } from "@/integrations/supabase/types";
type UserClient = SupabaseClient<Database>;

export type RateLimitResult = {
  allowed: boolean;
  count: number;
  limit: number;
  retry_after_seconds: number;
};

export async function enforceRateLimit(
  userClient: UserClient,
  action: string,
): Promise<RateLimitResult> {
  const { data, error } = await userClient.rpc("check_current_user_rate_limit", { _action: action });
  if (error) throw new Error(`rate limit check failed: ${error.message}`);
  return data as unknown as RateLimitResult;
}

export type UsageEvent = {
  eventType:
    | "process_document.requested"
    | "process_document.rejected"
    | "process_document.completed"
    | "process_document.failed"
    | "rag_chat.requested"
    | "rag_chat.rejected"
    | "rag_chat.completed"
    | "rag_chat.failed";
  status?: "ok" | "rejected" | "error";
  documentId?: string | null;
  errorCode?: string | null;
  errorMessage?: string | null;
  promptTokens?: number;
  completionTokens?: number;
  chunkCount?: number;
  conversationId?: string | null;
  metadata?: Record<string, unknown>;
};

export async function logUsage(userClient: UserClient, event: UsageEvent) {
  const args: Database["public"]["Functions"]["log_current_user_usage"]["Args"] = {
    _event_type: event.eventType,
    _status: event.status ?? "ok",
    _prompt_tokens: event.promptTokens ?? 0,
    _completion_tokens: event.completionTokens ?? 0,
    _chunk_count: event.chunkCount ?? 0,
    _metadata: (event.metadata ?? {}) as never,
  };
  if (event.documentId) args._document_id = event.documentId;
  if (event.errorCode) args._error_code = event.errorCode;
  if (event.errorMessage) args._error_message = event.errorMessage;
  if (event.conversationId) args._conversation_id = event.conversationId;
  const { error } = await userClient.rpc("log_current_user_usage", args);
  // Audit failures must never leak details to the client, but must be visible server-side.
  if (error) console.error("[audit] failed to log usage event", error.message);
}

/**
 * Authoritative document authorization: reads through the caller's RLS-scoped client,
 * then re-checks owner + organization explicitly. Returns null for any document the
 * caller does not own (cross-user or cross-org), indistinguishable from "not found".
 */
export async function authorizeDocument(userClient: UserClient, userId: string, documentId: string) {
  const { data, error } = await userClient
    .from("documents")
    .select("id, user_id, organization_id, knowledge_base_id, file_size, file_type, status")
    .eq("id", documentId)
    .maybeSingle();
  if (error) throw new Error(`document lookup failed: ${error.message}`);
  if (!data || data.user_id !== userId) return null;
  return data;
}

/** Same contract as authorizeDocument, for knowledge bases. */
export async function authorizeKnowledgeBase(userClient: UserClient, userId: string, knowledgeBaseId: string) {
  const { data, error } = await userClient
    .from("knowledge_bases")
    .select("id, user_id, organization_id")
    .eq("id", knowledgeBaseId)
    .maybeSingle();
  if (error) throw new Error(`knowledge base lookup failed: ${error.message}`);
  if (!data || data.user_id !== userId) return null;
  return data;
}

export type ClaimResult =
  | { ok: true; job_id: string }
  | { ok: false; code: "not_found" | "too_large_to_process" | "already_processing"; job_id?: string; max_processing_bytes?: number };

export async function claimProcessing(userClient: UserClient, documentId: string): Promise<ClaimResult> {
  const { data, error } = await userClient.rpc("claim_current_user_document_processing", { _document_id: documentId });
  if (error) throw new Error(`claim failed: ${error.message}`);
  return data as unknown as ClaimResult;
}

export async function finishProcessing(
  userClient: UserClient,
  jobId: string,
  outcome: "completed" | "failed" | "cancelled",
  errorMessage?: string,
  chunkCount = 0,
  metadata: Record<string, unknown> = {},
) {
  const { data, error } = await userClient.rpc("finish_current_user_document_processing", {
    _job_id: jobId,
    _outcome: outcome,
    _chunk_count: chunkCount,
    _metadata: metadata as never,
    ...(errorMessage ? { _error_message: errorMessage } : {}),
  });
  if (error) throw new Error(`finish failed: ${error.message}`);
  return data as unknown as { ok: boolean; code?: string; document_status?: string };
}

/**
 * Whether an AI provider key is configured. Read only here, only at call time,
 * and only as a boolean — the value is never returned, logged or forwarded.
 */
export function isAiProviderConfigured() {
  return Boolean(process.env["OPENAI_API_KEY"]);
}
