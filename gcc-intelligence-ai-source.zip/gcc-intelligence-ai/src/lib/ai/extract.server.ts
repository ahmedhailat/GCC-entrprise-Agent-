/**
 * Server-only real text extraction. No placeholder or invented text is ever produced:
 * when a file cannot be read, an ExtractionError is thrown with an honest reason.
 */
import type { ExtractedPage } from "@/lib/ai/chunk";
import { PROCESSABLE_EXTENSIONS, type ProcessableExtension } from "@/lib/ai/limits";

export class ExtractionError extends Error {
  code: "unsupported_type" | "empty_document" | "extraction_failed";
  constructor(code: ExtractionError["code"], message: string) {
    super(message);
    this.code = code;
  }
}

export function processableExtension(fileName: string, fileType: string): ProcessableExtension | null {
  const ext = (fileName.split(".").pop() ?? "").toLowerCase();
  if ((PROCESSABLE_EXTENSIONS as readonly string[]).includes(ext)) {
    return ext as ProcessableExtension;
  }
  if (fileType === "application/pdf") return "pdf";
  if (fileType === "text/plain") return "txt";
  if (fileType === "text/csv" || fileType === "application/csv") return "csv";
  return null;
}

function decodeText(bytes: Uint8Array) {
  return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
}

async function extractPdf(bytes: Uint8Array): Promise<ExtractedPage[]> {
  const { extractText, getDocumentProxy } = await import("unpdf");
  const pdf = await getDocumentProxy(bytes);
  const { text } = await extractText(pdf, { mergePages: false });
  const pages = Array.isArray(text) ? text : [String(text)];
  return pages.map((t, i) => ({ pageNumber: i + 1, text: t ?? "" }));
}

function extractCsv(bytes: Uint8Array): ExtractedPage[] {
  const raw = decodeText(bytes);
  const lines = raw.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length === 0) return [];
  const header = lines[0];
  // Keep the header alongside the rows so each chunk stays self-describing.
  const body = lines.slice(1);
  if (body.length === 0) return [{ pageNumber: null, text: header ?? "" }];
  const blockSize = 40;
  const pages: ExtractedPage[] = [];
  for (let i = 0; i < body.length; i += blockSize) {
    pages.push({
      pageNumber: null,
      text: [header, ...body.slice(i, i + blockSize)].join("\n"),
    });
  }
  return pages;
}

export async function extractDocumentText(
  bytes: Uint8Array,
  fileName: string,
  fileType: string,
): Promise<ExtractedPage[]> {
  const ext = processableExtension(fileName, fileType);
  if (!ext) {
    throw new ExtractionError(
      "unsupported_type",
      "Only PDF, TXT and CSV files can be processed at the moment.",
    );
  }

  let pages: ExtractedPage[];
  try {
    if (ext === "pdf") pages = await extractPdf(bytes);
    else if (ext === "csv") pages = extractCsv(bytes);
    else pages = [{ pageNumber: null, text: decodeText(bytes) }];
  } catch (error) {
    throw new ExtractionError(
      "extraction_failed",
      `Could not read the contents of this file: ${error instanceof Error ? error.message : "unknown error"}`,
    );
  }

  const hasText = pages.some((p) => p.text.trim().length > 0);
  if (!hasText) {
    throw new ExtractionError(
      "empty_document",
      "No readable text was found in this file. Scanned images are not supported yet.",
    );
  }
  return pages;
}
