/** Authenticated document processing and grounded retrieval-augmented generation. */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { PLATFORM_LIMITS, estimateTokens } from "@/lib/ai/limits";

const processDocumentInput = z.object({ documentId: z.string().uuid() });

const ragChatInput = z.object({
  knowledgeBaseId: z.string().uuid().nullable().optional(),
  documentId: z.string().uuid().nullable().optional(),
  message: z.string().trim().min(1).max(PLATFORM_LIMITS.maxChatMessageChars),
  /** Client may ask for fewer chunks; the server caps it at maxRetrievedChunks. */
  maxChunks: z.number().int().min(1).max(100).optional(),
});

export type ProcessDocumentResult =
  | { ok: true; jobId: string; chunkCount: number; extractedCharacters: number; durationMs: number }
  | { ok: false; code: "not_found" | "rate_limited" | "too_large_to_process" | "already_processing" | "unsupported_type" | "invalid_storage_path" | "ai_not_configured" | "error"; message?: string; retryAfterSeconds?: number };

export const processDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => processDocumentInput.parse(input))
  .handler(async ({ data, context }): Promise<ProcessDocumentResult> => {
    const { userId, supabase } = context;
    const guards = await import("@/lib/ai/guards.server");

    // 1. Rate limit (DB-backed, per user).
    const rl = await guards.enforceRateLimit(supabase, "process_document");
    if (!rl.allowed) {
      return { ok: false, code: "rate_limited", retryAfterSeconds: rl.retry_after_seconds };
    }

    // 2. Authoritative authorization (RLS + explicit owner check).
    const doc = await guards.authorizeDocument(supabase, userId, data.documentId);
    if (!doc) {
      await guards.logUsage(supabase, { eventType: "process_document.rejected", status: "rejected", errorCode: "not_found" });
      return { ok: false, code: "not_found" };
    }

    // 3. Processing size limit (also re-checked inside the claim function).
    if (doc.file_size > PLATFORM_LIMITS.maxProcessingBytes) {
      await guards.logUsage(supabase, { eventType: "process_document.rejected", status: "rejected", documentId: doc.id, errorCode: "too_large_to_process" });
      return { ok: false, code: "too_large_to_process" };
    }

    // 4. Idempotent lock: one active job per document.
    const claim = await guards.claimProcessing(supabase, doc.id);
    if (!claim.ok) {
      await guards.logUsage(supabase, { eventType: "process_document.rejected", status: "rejected", documentId: doc.id, errorCode: claim.code });
      return { ok: false, code: claim.code };
    }
    await guards.logUsage(supabase, { eventType: "process_document.requested", documentId: doc.id, metadata: { jobId: claim.job_id, fileSize: doc.file_size } });

    // 5. No AI provider configured: release the lock honestly, document returns to "ready".
    if (!guards.isAiProviderConfigured()) {
      await guards.finishProcessing(supabase, claim.job_id, "failed", "OPENAI_API_KEY is not configured on the server.");
      await guards.logUsage(supabase, { eventType: "process_document.rejected", status: "rejected", documentId: doc.id, errorCode: "ai_not_configured", metadata: { jobId: claim.job_id } });
      return { ok: false, code: "ai_not_configured" };
    }

    const startedAt = Date.now();
    try {
      const [{ extractDocumentText }, { chunkPages }, ai, retrieval] = await Promise.all([
        import("@/lib/ai/extract.server"),
        import("@/lib/ai/chunk"),
        import("@/lib/ai/openai.server"),
        import("@/lib/ai/retrieval.server"),
      ]);
      const ownedDoc = await guards.authorizeDocument(supabase, userId, data.documentId);
      if (!ownedDoc) throw new Error("Document is no longer available.");
      const { data: fullDoc, error: fullDocError } = await supabase
        .from("documents")
        .select("file_path,file_name,file_type")
        .eq("id", data.documentId)
        .single();
      if (fullDocError) throw new Error(`document lookup failed: ${fullDocError.message}`);
      const bytes = await retrieval.downloadDocumentFile(supabase, fullDoc.file_path);
      const pages = await extractDocumentText(bytes, fullDoc.file_name, fullDoc.file_type);
      const extractedCharacters = pages.reduce((sum, page) => sum + page.text.length, 0);
      const chunked = chunkPages(pages);
      if (chunked.chunks.length === 0) throw new Error("No non-empty passages were extracted.");
      if (chunked.truncated) throw new Error(`Document exceeds the ${PLATFORM_LIMITS.maxChunksPerDocument}-chunk processing limit.`);
      const embedded = await ai.embedTexts(chunked.chunks.map((chunk) => chunk.content));
      if (embedded.vectors.length !== chunked.chunks.length || embedded.vectors.some((vector) => vector.length !== ai.EMBEDDING_DIMENSIONS)) {
        throw new Error("Embedding response did not match the document passages.");
      }
      const chunkCount = await retrieval.replaceChunks(supabase, doc.id, chunked.chunks, embedded.vectors);
      const durationMs = Date.now() - startedAt;
      const metadata = { extractedCharacters, pages: pages.length, embeddingModel: ai.EMBEDDING_MODEL, embeddingDimensions: ai.EMBEDDING_DIMENSIONS, durationMs };
      await guards.finishProcessing(supabase, claim.job_id, "completed", undefined, chunkCount, metadata);
      await guards.logUsage(supabase, { eventType: "process_document.completed", documentId: doc.id, promptTokens: embedded.usage.promptTokens, chunkCount, metadata: { jobId: claim.job_id, ...metadata } });
      return { ok: true, jobId: claim.job_id, chunkCount, extractedCharacters, durationMs };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Document processing failed.";
      await guards.finishProcessing(supabase, claim.job_id, "failed", message, 0, { durationMs: Date.now() - startedAt });
      await guards.logUsage(supabase, { eventType: "process_document.failed", status: "error", documentId: doc.id, errorCode: error instanceof Error && "code" in error ? String(error.code) : "processing_failed", errorMessage: message, metadata: { jobId: claim.job_id } });
      return { ok: false, code: "error", message };
    }
  });

export type RagChatResult =
  | { ok: true; answer: string; retrievedChunks: number; sources: Array<{ citation: number; documentId: string; chunkId: string; fileName: string; pageNumber: number | null; similarity: number }> }
  | { ok: false; code: "not_found" | "rate_limited" | "ai_not_configured" | "error"; message?: string; retryAfterSeconds?: number };

export const ragChat = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ragChatInput.parse(input))
  .handler(async ({ data, context }): Promise<RagChatResult> => {
    const { userId, supabase } = context;
    const guards = await import("@/lib/ai/guards.server");

    // 1. Rate limits: burst (per minute) and daily.
    const perMinute = await guards.enforceRateLimit(supabase, "rag_chat");
    if (!perMinute.allowed) return { ok: false, code: "rate_limited", retryAfterSeconds: perMinute.retry_after_seconds };
    const perDay = await guards.enforceRateLimit(supabase, "rag_chat_daily");
    if (!perDay.allowed) return { ok: false, code: "rate_limited", retryAfterSeconds: perDay.retry_after_seconds };

    // 2. Authorize the scope (knowledge base and/or document) — no cross-user/org access.
    if (data.knowledgeBaseId) {
      const kb = await guards.authorizeKnowledgeBase(supabase, userId, data.knowledgeBaseId);
      if (!kb) {
        await guards.logUsage(supabase, { eventType: "rag_chat.rejected", status: "rejected", errorCode: "not_found" });
        return { ok: false, code: "not_found" };
      }
    }
    if (data.documentId) {
      const doc = await guards.authorizeDocument(supabase, userId, data.documentId);
      if (!doc) {
        await guards.logUsage(supabase, { eventType: "rag_chat.rejected", status: "rejected", errorCode: "not_found" });
        return { ok: false, code: "not_found" };
      }
    }

    // 3. Hard cap on retrieved chunks, regardless of what the client asked for.
    const maxChunks = Math.min(data.maxChunks ?? PLATFORM_LIMITS.maxRetrievedChunks, PLATFORM_LIMITS.maxRetrievedChunks);
    const promptTokens = estimateTokens(data.message);

    await guards.logUsage(supabase, {
      eventType: "rag_chat.requested",
      documentId: data.documentId ?? null,
      promptTokens,
      metadata: { knowledgeBaseId: data.knowledgeBaseId ?? null, maxChunks, messageChars: data.message.length },
    });

    if (!guards.isAiProviderConfigured()) {
      await guards.logUsage(supabase, { eventType: "rag_chat.rejected", status: "rejected", documentId: data.documentId ?? null, errorCode: "ai_not_configured" });
      return { ok: false, code: "ai_not_configured" };
    }

    try {
      const [ai, retrieval] = await Promise.all([
        import("@/lib/ai/openai.server"),
        import("@/lib/ai/retrieval.server"),
      ]);
      const queryEmbedding = await ai.embedTexts([data.message]);
      const chunks = await retrieval.matchChunks({
        userClient: supabase,
        queryEmbedding: queryEmbedding.vectors[0] ?? [],
        knowledgeBaseId: data.knowledgeBaseId ?? null,
        documentId: data.documentId ?? null,
        matchCount: maxChunks,
        similarityThreshold: 0.2,
      });
      if (chunks.length === 0) {
        await guards.logUsage(supabase, { eventType: "rag_chat.completed", documentId: data.documentId ?? null, promptTokens: queryEmbedding.usage.promptTokens, chunkCount: 0, metadata: { insufficientInformation: true } });
        return { ok: true, answer: ai.NO_ANSWER, retrievedChunks: 0, sources: [] };
      }
      const response = await ai.answerFromContext(data.message, chunks.map((chunk) => chunk.content));
      const sources = chunks.map((chunk, index) => ({ citation: index + 1, documentId: chunk.document_id, chunkId: chunk.chunk_id, fileName: chunk.file_name, pageNumber: chunk.page_number, similarity: chunk.similarity }));
      await guards.logUsage(supabase, { eventType: "rag_chat.completed", documentId: data.documentId ?? null, promptTokens: queryEmbedding.usage.promptTokens + response.promptTokens, completionTokens: response.completionTokens, chunkCount: chunks.length, metadata: { knowledgeBaseId: data.knowledgeBaseId ?? null, insufficientInformation: response.answer === ai.NO_ANSWER } });
      return { ok: true, answer: response.answer, retrievedChunks: chunks.length, sources };
    } catch (error) {
      const message = error instanceof Error ? error.message : "RAG request failed.";
      await guards.logUsage(supabase, { eventType: "rag_chat.failed", status: "error", documentId: data.documentId ?? null, errorCode: "rag_failed", errorMessage: message });
      return { ok: false, code: "error", message };
    }
  });
