/**
 * Server-only OpenAI access. The API key is read from the server environment at call
 * time and never returned, logged or forwarded anywhere.
 */
export const EMBEDDING_MODEL = "text-embedding-3-small";
export const EMBEDDING_DIMENSIONS = 1536;
export const CHAT_MODEL = "gpt-4o-mini";

export class AiNotConfiguredError extends Error {
  constructor() {
    super("OPENAI_API_KEY is not configured on the server.");
  }
}

export class AiRequestError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function apiKey() {
  const key = process.env["OPENAI_API_KEY"];
  if (!key) throw new AiNotConfiguredError();
  return key;
}

export function isAiConfigured() {
  return Boolean(process.env["OPENAI_API_KEY"]);
}

async function openaiFetch(path: string, body: unknown) {
  const res = await fetch(`https://api.openai.com/v1${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey()}`,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    let message = text.slice(0, 500);
    try {
      const parsed = JSON.parse(text) as { error?: { message?: string } };
      if (parsed.error?.message) message = parsed.error.message;
    } catch {
      /* keep raw text */
    }
    throw new AiRequestError(res.status, message || `OpenAI request failed (${res.status})`);
  }
  return res.json();
}

export type EmbeddingUsage = { promptTokens: number };

/** Embeds a batch of strings; returns vectors in input order. */
export async function embedTexts(
  inputs: string[],
): Promise<{ vectors: number[][]; usage: EmbeddingUsage }> {
  const vectors: number[][] = [];
  let promptTokens = 0;
  const BATCH = 64;

  for (let i = 0; i < inputs.length; i += BATCH) {
    const batch = inputs.slice(i, i + BATCH);
    const json = (await openaiFetch("/embeddings", {
      model: EMBEDDING_MODEL,
      input: batch,
      dimensions: EMBEDDING_DIMENSIONS,
    })) as {
      data: { index: number; embedding: number[] }[];
      usage?: { prompt_tokens?: number };
    };
    const ordered = [...json.data].sort((a, b) => a.index - b.index);
    for (const row of ordered) vectors.push(row.embedding);
    promptTokens += json.usage?.prompt_tokens ?? 0;
  }

  return { vectors, usage: { promptTokens } };
}

export const NO_ANSWER =
  "I could not find sufficient information in the available knowledge base.";

export type ChatResult = {
  answer: string;
  promptTokens: number;
  completionTokens: number;
};

export async function answerFromContext(
  question: string,
  contextBlocks: string[],
): Promise<ChatResult> {
  const system = [
    "You are GCC Intelligence AI, an enterprise document assistant.",
    "Answer ONLY using the numbered context passages provided by the user message.",
    "Never use outside knowledge, never guess, and never invent figures, names or dates.",
    "Cite the passage numbers you used, like [1] or [2][3].",
    `If the context does not contain enough information to answer, reply with exactly: "${NO_ANSWER}"`,
  ].join(" ");

  const context = contextBlocks.length
    ? contextBlocks.map((block, i) => `[${i + 1}]\n${block}`).join("\n\n---\n\n")
    : "(no passages retrieved)";

  const json = (await openaiFetch("/chat/completions", {
    model: CHAT_MODEL,
    temperature: 0,
    max_tokens: 800,
    messages: [
      { role: "system", content: system },
      { role: "user", content: `Context passages:\n\n${context}\n\nQuestion: ${question}` },
    ],
  })) as {
    choices: { message?: { content?: string } }[];
    usage?: { prompt_tokens?: number; completion_tokens?: number };
  };

  return {
    answer: json.choices[0]?.message?.content?.trim() || NO_ANSWER,
    promptTokens: json.usage?.prompt_tokens ?? 0,
    completionTokens: json.usage?.completion_tokens ?? 0,
  };
}
