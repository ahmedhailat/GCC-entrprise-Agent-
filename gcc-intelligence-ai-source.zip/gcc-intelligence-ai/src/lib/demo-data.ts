/**
 * DEMO DATA — Phase 1 only.
 * Static, clearly labelled sample content used to illustrate the dashboard layout.
 * No real analytics, no AI processing. Replaced by live data in Phase 2.
 */

export const DEMO_LABEL = "Demo data";

export type Metric = {
  id: string;
  label: string;
  value: string;
  change: string;
  trend: "up" | "down";
  hint: string;
};

export const demoMetrics: Metric[] = [
  {
    id: "documents",
    label: "Documents indexed",
    value: "1,284",
    change: "+8.4%",
    trend: "up",
    hint: "Sample figure for layout purposes",
  },
  {
    id: "conversations",
    label: "Conversations",
    value: "342",
    change: "+12.1%",
    trend: "up",
    hint: "Sample figure for layout purposes",
  },
  {
    id: "workspace",
    label: "Active seats",
    value: "27",
    change: "+3",
    trend: "up",
    hint: "Sample figure for layout purposes",
  },
  {
    id: "compliance",
    label: "Compliance checks",
    value: "98.6%",
    change: "-0.4%",
    trend: "down",
    hint: "Sample figure for layout purposes",
  },
];

export type UsagePoint = { month: string; documents: number; queries: number };

export const demoUsage: UsagePoint[] = [
  { month: "Jan", documents: 180, queries: 320 },
  { month: "Feb", documents: 240, queries: 410 },
  { month: "Mar", documents: 310, queries: 520 },
  { month: "Apr", documents: 280, queries: 610 },
  { month: "May", documents: 390, queries: 740 },
  { month: "Jun", documents: 460, queries: 880 },
];

export type ActivityItem = {
  id: string;
  actor: string;
  action: string;
  target: string;
  time: string;
  kind: "document" | "conversation" | "member" | "security";
};

export const demoActivity: ActivityItem[] = [
  {
    id: "a1",
    actor: "Layla Al Mansouri",
    action: "uploaded",
    target: "Q2 Regulatory Filing — UAE.pdf",
    time: "12 minutes ago",
    kind: "document",
  },
  {
    id: "a2",
    actor: "Omar Al Qahtani",
    action: "started a conversation in",
    target: "Saudi Vision 2030 Tenders",
    time: "1 hour ago",
    kind: "conversation",
  },
  {
    id: "a3",
    actor: "Workspace admin",
    action: "invited",
    target: "finance@example-holding.ae",
    time: "3 hours ago",
    kind: "member",
  },
  {
    id: "a4",
    actor: "Security policy",
    action: "rotated encryption keys for",
    target: "Doha data residency zone",
    time: "Yesterday",
    kind: "security",
  },
  {
    id: "a5",
    actor: "Noura Al Sabah",
    action: "archived",
    target: "2024 Kuwait Procurement Notes",
    time: "2 days ago",
    kind: "document",
  },
];

export type DemoDocument = {
  id: string;
  name: string;
  category: string;
  owner: string;
  size: string;
  updated: string;
  status: "Indexed" | "Processing" | "Archived";
};

export const demoDocuments: DemoDocument[] = [
  {
    id: "d1",
    name: "Q2 Regulatory Filing — UAE.pdf",
    category: "Compliance",
    owner: "Layla Al Mansouri",
    size: "4.2 MB",
    updated: "Today",
    status: "Indexed",
  },
  {
    id: "d2",
    name: "Saudi Vision 2030 Tender Pack.docx",
    category: "Tenders",
    owner: "Omar Al Qahtani",
    size: "1.8 MB",
    updated: "Yesterday",
    status: "Processing",
  },
  {
    id: "d3",
    name: "Qatar Energy Market Brief.pdf",
    category: "Market research",
    owner: "Hessa Al Thani",
    size: "912 KB",
    updated: "3 days ago",
    status: "Indexed",
  },
  {
    id: "d4",
    name: "Group Board Pack — May.pptx",
    category: "Executive",
    owner: "Workspace admin",
    size: "12.4 MB",
    updated: "1 week ago",
    status: "Indexed",
  },
  {
    id: "d5",
    name: "2024 Kuwait Procurement Notes.md",
    category: "Procurement",
    owner: "Noura Al Sabah",
    size: "48 KB",
    updated: "2 weeks ago",
    status: "Archived",
  },
];

export type DemoConversation = {
  id: string;
  title: string;
  preview: string;
  messages: number;
  updated: string;
  workspace: string;
};

export const demoConversations: DemoConversation[] = [
  {
    id: "c1",
    title: "Summarise UAE ESG reporting duties",
    preview: "Which disclosures apply to listed holdings from FY2026 onward?",
    messages: 14,
    updated: "12 min ago",
    workspace: "Compliance",
  },
  {
    id: "c2",
    title: "Tender eligibility screening",
    preview: "Compare our qualification pack against the Vision 2030 tender criteria.",
    messages: 26,
    updated: "1 hour ago",
    workspace: "Tenders",
  },
  {
    id: "c3",
    title: "Energy market outlook Q3",
    preview: "Key demand drivers across Qatar and Oman for the next quarter.",
    messages: 9,
    updated: "Yesterday",
    workspace: "Research",
  },
  {
    id: "c4",
    title: "Board pack talking points",
    preview: "Draft five executive talking points from the May board pack.",
    messages: 7,
    updated: "4 days ago",
    workspace: "Executive",
  },
];
