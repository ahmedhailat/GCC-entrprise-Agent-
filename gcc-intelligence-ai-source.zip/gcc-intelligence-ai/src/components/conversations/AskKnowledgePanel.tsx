import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { ragChat, type RagChatResult } from "@/lib/ai/ai.functions";

/** Real grounded question answering over the signed-in user's processed documents. */
export function AskKnowledgePanel() {
  const ask = useServerFn(ragChat);
  const [message, setMessage] = useState("");
  const [pending, setPending] = useState(false);
  const [result, setResult] = useState<RagChatResult | null>(null);

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!message.trim()) return;
    setPending(true);
    try {
      setResult(await ask({ data: { message } }));
    } catch (err) {
      setResult({ ok: false, code: "error", message: err instanceof Error ? err.message : "Request failed." });
    } finally {
      setPending(false);
    }
  }

  return (
    <Card className="mb-6 border-border/70">
      <CardHeader>
        <CardTitle className="text-base">Ask your documents</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={onSubmit} className="space-y-3">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ask a question about your processed documents…"
            maxLength={4000}
          />
          <Button type="submit" disabled={pending || !message.trim()}>
            {pending ? "Searching…" : "Ask"}
          </Button>
        </form>
        {result && (
          <div className="mt-4 space-y-3 text-sm">
            {result.ok ? (
              <>
                <p className="whitespace-pre-wrap">{result.answer}</p>
                {result.sources.length > 0 && (
                  <ul className="space-y-1 text-xs text-muted-foreground">
                    {result.sources.map((s) => (
                      <li key={s.chunkId}>
                        [{s.citation}] {s.fileName}
                        {s.pageNumber ? `, page ${s.pageNumber}` : ""} — match {s.similarity.toFixed(2)}
                      </li>
                    ))}
                  </ul>
                )}
              </>
            ) : (
              <p className="text-destructive">
                {result.code === "rate_limited"
                  ? `Too many questions. Try again in ${result.retryAfterSeconds ?? 60}s.`
                  : (result.message ?? result.code.replace(/_/g, " "))}
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
