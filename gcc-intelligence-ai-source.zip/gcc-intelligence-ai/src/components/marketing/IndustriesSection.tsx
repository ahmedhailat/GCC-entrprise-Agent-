const industries = [
  { name: "Banking & capital markets", copy: "Regulatory filings, credit files and disclosure packs." },
  { name: "Energy & utilities", copy: "Project documentation, market briefs and tender records." },
  { name: "Government & public sector", copy: "Policy libraries, procurement notes and correspondence." },
  { name: "Holding groups", copy: "Board packs, subsidiary reporting and executive summaries." },
  { name: "Real estate & construction", copy: "Contracts, approvals and delivery documentation." },
  { name: "Healthcare providers", copy: "Accreditation evidence and operational governance records." },
];

export function IndustriesSection() {
  return (
    <section id="industries" className="border-b border-border/60 py-20 lg:py-28">
      <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
        <div className="max-w-2xl">
          <p className="text-xs uppercase tracking-[0.2em] text-primary">Industries</p>
          <h2 className="mt-4 text-3xl font-semibold sm:text-4xl">
            Designed around how Gulf enterprises actually work
          </h2>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {industries.map((industry) => (
            <div
              key={industry.name}
              className="rounded-xl border border-border bg-card/50 p-6 transition-colors hover:border-accent/50"
            >
              <h3 className="text-sm font-semibold">{industry.name}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{industry.copy}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
