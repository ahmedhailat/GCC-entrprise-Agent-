import { Fingerprint, KeyRound, Lock, ScrollText } from "lucide-react";

const items = [
  {
    icon: Lock,
    title: "Row-level data isolation",
    copy: "Every record is scoped to its owner at the database layer, not just in the interface.",
  },
  {
    icon: KeyRound,
    title: "Managed credentials",
    copy: "Passwords and sessions are handled by a managed identity service — never stored in the app.",
  },
  {
    icon: Fingerprint,
    title: "Least-privilege access",
    copy: "Accounts receive only the permissions their role requires, enforced server side.",
  },
  {
    icon: ScrollText,
    title: "Audit-ready activity",
    copy: "A clear timeline of workspace events designed for internal review and reporting.",
  },
];

export function SecuritySection() {
  return (
    <section id="security" className="border-b border-border/60 py-20 lg:py-28">
      <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
        <div className="max-w-2xl">
          <p className="text-xs uppercase tracking-[0.2em] text-primary">Security &amp; governance</p>
          <h2 className="mt-4 text-3xl font-semibold sm:text-4xl">
            Trust is a requirement, not a feature tier
          </h2>
        </div>

        <div className="mt-12 grid gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-2">
          {items.map((item) => (
            <div key={item.title} className="bg-card p-7">
              <item.icon className="size-5 text-accent" />
              <h3 className="mt-4 text-base font-semibold">{item.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{item.copy}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
