import {
  Boxes,
  FileStack,
  Gauge,
  Languages,
  MessagesSquare,
  Workflow,
} from "lucide-react";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const features = [
  {
    icon: FileStack,
    title: "Unified document workspace",
    description:
      "Bring contracts, filings and board packs into one governed library with ownership, categories and full revision history.",
  },
  {
    icon: MessagesSquare,
    title: "Team conversations",
    description:
      "Keep every question, answer and decision attached to the work it came from, organised by business function.",
  },
  {
    icon: Gauge,
    title: "Operational visibility",
    description:
      "Executive dashboards summarise workspace adoption, document coverage and compliance posture at a glance.",
  },
  {
    icon: Languages,
    title: "Bilingual by design",
    description:
      "An interface and content model prepared for Arabic and English side by side across every GCC market.",
  },
  {
    icon: Workflow,
    title: "Role-based workflows",
    description:
      "Structured spaces for compliance, tenders, research and executive teams, each with their own access boundaries.",
  },
  {
    icon: Boxes,
    title: "Composable architecture",
    description:
      "A clean, typed React component system and a normalised data model built to extend without a rewrite.",
  },
];

export function FeatureGrid() {
  return (
    <section id="capabilities" className="border-b border-border/60 py-20 lg:py-28">
      <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
        <div className="max-w-2xl">
          <p className="text-xs uppercase tracking-[0.2em] text-primary">Capabilities</p>
          <h2 className="mt-4 text-3xl font-semibold sm:text-4xl">
            One platform for the knowledge your enterprise runs on
          </h2>
          <p className="mt-4 text-muted-foreground">
            Everything below is part of the foundation release — structured, secure and ready for
            deeper intelligence features as they roll out.
          </p>
        </div>

        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <Card
              key={feature.title}
              className="border-border/70 bg-card/60 transition-colors hover:border-primary/40"
            >
              <CardHeader>
                <span className="inline-flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary ring-1 ring-primary/25">
                  <feature.icon className="size-5" />
                </span>
                <CardTitle className="mt-4 text-base">{feature.title}</CardTitle>
                <CardDescription>{feature.description}</CardDescription>
              </CardHeader>
              <CardContent />
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
