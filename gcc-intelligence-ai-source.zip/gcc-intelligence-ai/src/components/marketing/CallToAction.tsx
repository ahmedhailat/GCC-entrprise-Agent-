import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";

import { Button } from "@/components/ui/button";

export function CallToAction() {
  return (
    <section className="border-b border-border/60 py-20 lg:py-24">
      <div className="mx-auto w-full max-w-5xl px-5 sm:px-8">
        <div className="relative overflow-hidden rounded-2xl border border-border bg-card px-7 py-14 text-center sm:px-14">
          <div className="pointer-events-none absolute -top-24 left-1/2 size-72 -translate-x-1/2 rounded-full bg-primary/15 blur-3xl" />
          <div className="relative">
            <h2 className="text-3xl font-semibold sm:text-4xl">
              Bring your enterprise knowledge into one secure workspace
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
              Create an account to explore the workspace foundation — profile, dashboard, documents
              and conversations.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button asChild size="lg">
                <Link to="/auth" search={{ mode: "signup" }}>
                  Create your account
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/auth" search={{ mode: "signin" }}>Sign in</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
