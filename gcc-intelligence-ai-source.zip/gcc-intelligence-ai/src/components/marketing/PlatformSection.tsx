import { Check } from "lucide-react";

const pillars = [
  {
    title: "Ingest",
    copy: "Centralise documents and operational records into a governed, searchable workspace.",
  },
  {
    title: "Organise",
    copy: "Structure knowledge by function, market and sensitivity with clear ownership.",
  },
  {
    title: "Act",
    copy: "Give teams a single place to review, discuss and act on what matters this week.",
  },
];

const included = [
  "Secure account provisioning and password recovery",
  "Company profile with editable identity details",
  "Executive dashboard with workspace metrics",
  "Document library and conversation history views",
  "Audit-style activity timeline",
];

export function PlatformSection() {
  return (
    <section id="platform" className="border-b border-border/60 py-20 lg:py-28">
      <div className="mx-auto grid w-full max-w-7xl gap-14 px-5 sm:px-8 lg:grid-cols-2 lg:items-center">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-primary">The platform</p>
          <h2 className="mt-4 text-3xl font-semibold sm:text-4xl">
            A disciplined foundation before a single model runs
          </h2>
          <p className="mt-4 text-muted-foreground">
            Enterprise intelligence fails when the underlying workspace is messy. We start with
            identity, structure and governance — so every capability added later inherits the same
            guarantees.
          </p>

          <ul className="mt-8 space-y-3">
            {included.map((item) => (
              <li key={item} className="flex items-start gap-3 text-sm">
                <span className="mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full bg-success/15 text-success">
                  <Check className="size-3.5" />
                </span>
                <span className="text-muted-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="grid gap-4">
          {pillars.map((pillar, index) => (
            <div
              key={pillar.title}
              className="rounded-xl border border-border bg-card/60 p-6 transition-colors hover:border-primary/40"
            >
              <div className="flex items-center gap-3">
                <span className="font-display text-sm text-primary">
                  0{index + 1}
                </span>
                <h3 className="text-base font-semibold">{pillar.title}</h3>
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{pillar.copy}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
