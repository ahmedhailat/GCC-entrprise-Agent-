import { BrandMark } from "@/components/brand/BrandMark";

export function SiteFooter() {
  return (
    <footer className="py-12">
      <div className="mx-auto flex w-full max-w-7xl flex-col gap-8 px-5 sm:px-8 md:flex-row md:items-start md:justify-between">
        <div className="max-w-sm">
          <BrandMark />
          <p className="mt-4 text-sm text-muted-foreground">
            Enterprise intelligence, engineered for the GCC. Secure, governed and built for regulated
            organisations across the Gulf.
          </p>
        </div>

        <nav aria-label="Footer" className="grid grid-cols-2 gap-8 text-sm sm:grid-cols-3">
          <div>
            <p className="font-semibold">Platform</p>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>
                <a href="#platform" className="hover:text-foreground">
                  Overview
                </a>
              </li>
              <li>
                <a href="#capabilities" className="hover:text-foreground">
                  Capabilities
                </a>
              </li>
              <li>
                <a href="#security" className="hover:text-foreground">
                  Security
                </a>
              </li>
            </ul>
          </div>
          <div>
            <p className="font-semibold">Company</p>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>
                <a href="#industries" className="hover:text-foreground">
                  Industries
                </a>
              </li>
              <li>
                <a href="#platform" className="hover:text-foreground">
                  Approach
                </a>
              </li>
            </ul>
          </div>
          <div>
            <p className="font-semibold">Access</p>
            <ul className="mt-3 space-y-2 text-muted-foreground">
              <li>
                <a href="/auth" className="hover:text-foreground">
                  Sign in
                </a>
              </li>
              <li>
                <a href="/auth?mode=signup" className="hover:text-foreground">
                  Request access
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </div>

      <div className="mx-auto mt-10 w-full max-w-7xl px-5 sm:px-8">
        <p className="border-t border-border/60 pt-6 text-xs text-muted-foreground">
          © {new Date().getFullYear()} GCC Intelligence AI. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
