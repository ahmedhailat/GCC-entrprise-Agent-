import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { STATUS_META, type DocumentStatus } from "@/lib/documents";

const styles: Record<DocumentStatus, string> = {
  uploaded: "border-border bg-muted/40 text-muted-foreground",
  processing: "border-accent/40 bg-accent/10 text-accent",
  ready: "border-primary/40 bg-primary/10 text-primary",
  failed: "border-destructive/40 bg-destructive/10 text-destructive",
};

export function DocumentStatusBadge({
  status,
  className,
}: {
  status: DocumentStatus;
  className?: string;
}) {
  return (
    <Badge variant="outline" className={cn("font-normal", styles[status], className)}>
      {STATUS_META[status].label}
    </Badge>
  );
}
