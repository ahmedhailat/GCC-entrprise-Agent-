import { useRef, useState } from "react";
import { Upload } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useUploadDocument } from "@/hooks/useDocuments";
import { useKnowledgeBases } from "@/hooks/useKnowledgeBases";
import { ACCEPT_ATTRIBUTE, MAX_FILE_SIZE, formatBytes, validateFile } from "@/lib/documents";

const NONE = "none";

export function UploadDocumentDialog({
  defaultKnowledgeBaseId,
  lockKnowledgeBase = false,
}: {
  defaultKnowledgeBaseId?: string;
  lockKnowledgeBase?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [knowledgeBaseId, setKnowledgeBaseId] = useState<string>(defaultKnowledgeBaseId ?? NONE);
  const [fileError, setFileError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: knowledgeBases } = useKnowledgeBases();
  const upload = useUploadDocument();

  function reset() {
    setFile(null);
    setTitle("");
    setDescription("");
    setKnowledgeBaseId(defaultKnowledgeBaseId ?? NONE);
    setFileError(null);
    setProgress(0);
    if (inputRef.current) inputRef.current.value = "";
  }

  function handleFileChange(selected: File | null) {
    setFileError(null);
    if (!selected) {
      setFile(null);
      return;
    }
    const error = validateFile(selected);
    if (error) {
      setFile(null);
      setFileError(error);
      return;
    }
    setFile(selected);
    if (!title.trim()) setTitle(selected.name.replace(/\.[^.]+$/, ""));
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!file) {
      setFileError("Choose a file to upload.");
      return;
    }
    try {
      await upload.mutateAsync({
        file,
        title,
        description,
        knowledgeBaseId: knowledgeBaseId === NONE ? null : knowledgeBaseId,
        onProgress: setProgress,
      });
      toast.success("Document uploaded", { description: file.name });
      reset();
      setOpen(false);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Upload failed. Please try again.";
      toast.error("Upload failed", { description: message });
      setProgress(0);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (upload.isPending) return;
        setOpen(next);
        if (!next) reset();
      }}
    >
      <DialogTrigger asChild>
        <Button>
          <Upload className="size-4" />
          Upload document
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Upload a document</DialogTitle>
          <DialogDescription>
            PDF, CSV or TXT, up to {formatBytes(MAX_FILE_SIZE)}. Files are stored
            privately and only you can open them.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="document-file">File</Label>
            <Input
              id="document-file"
              ref={inputRef}
              type="file"
              accept={ACCEPT_ATTRIBUTE}
              disabled={upload.isPending}
              onChange={(e) => handleFileChange(e.target.files?.[0] ?? null)}
            />
            {file ? (
              <p className="text-xs text-muted-foreground">
                {file.name} · {formatBytes(file.size)}
              </p>
            ) : null}
            {fileError ? <p className="text-xs text-destructive">{fileError}</p> : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="document-title">Title</Label>
            <Input
              id="document-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Give this document a clear name"
              disabled={upload.isPending}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="document-description">Description (optional)</Label>
            <Textarea
              id="document-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What is this document for?"
              rows={3}
              disabled={upload.isPending}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="document-kb">Knowledge base</Label>
            <Select
              value={knowledgeBaseId}
              onValueChange={setKnowledgeBaseId}
              disabled={upload.isPending || lockKnowledgeBase}
            >
              <SelectTrigger id="document-kb">
                <SelectValue placeholder="Unassigned" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={NONE}>Unassigned</SelectItem>
                {(knowledgeBases ?? []).map((kb) => (
                  <SelectItem key={kb.id} value={kb.id}>
                    {kb.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {upload.isPending ? (
            <div className="space-y-2">
              <Progress value={progress} />
              <p className="text-xs text-muted-foreground">Uploading… {progress}%</p>
            </div>
          ) : null}

          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              onClick={() => setOpen(false)}
              disabled={upload.isPending}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={upload.isPending}>
              {upload.isPending ? "Uploading…" : "Upload"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
