import { Info } from "lucide-react";

import { cn } from "@/lib/utils";

/** Marks any sample content shown while real data sources arrive in Phase 2. */
export function DemoBadge({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-accent/40 bg-accent/10 px-2.5 py-1 text-[11px] font-medium uppercase tracking-[0.1em] text-accent",
        className,
      )}
    >
      <Info className="size-3" />
      Demo data
    </span>
  );
}

export function DemoNotice({ children }: { children: string }) {
  return (
    <div className="mb-6 flex flex-col gap-2 rounded-xl border border-accent/30 bg-accent/5 px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
      <p className="text-sm text-muted-foreground">{children}</p>
      <DemoBadge />
    </div>
  );
}
