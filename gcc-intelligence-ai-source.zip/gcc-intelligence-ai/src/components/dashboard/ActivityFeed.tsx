import { FileText, MessagesSquare, ShieldCheck, UserPlus } from "lucide-react";

import type { ActivityItem } from "@/lib/demo-data";

const iconFor = {
  document: FileText,
  conversation: MessagesSquare,
  member: UserPlus,
  security: ShieldCheck,
} as const;

export function ActivityFeed({ items }: { items: ActivityItem[] }) {
  return (
    <ol className="space-y-4">
      {items.map((item) => {
        const Icon = iconFor[item.kind];
        return (
          <li key={item.id} className="flex gap-3">
            <span className="mt-0.5 inline-flex size-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-muted-foreground">
              <Icon className="size-4" />
            </span>
            <div className="min-w-0">
              <p className="text-sm">
                <span className="font-medium text-foreground">{item.actor}</span>{" "}
                <span className="text-muted-foreground">{item.action}</span>{" "}
                <span className="text-foreground">{item.target}</span>
              </p>
              <p className="mt-1 text-xs text-muted-foreground">{item.time}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
