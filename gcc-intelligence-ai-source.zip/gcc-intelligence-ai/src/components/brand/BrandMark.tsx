import { Link } from "@tanstack/react-router";

import { cn } from "@/lib/utils";

export function BrandMark({ className, to = "/" }: { className?: string; to?: string }) {
  return (
    <Link
      to={to}
      className={cn("group inline-flex items-center gap-3", className)}
      aria-label="GCC Intelligence AI home"
    >
      <span className="relative inline-flex size-9 items-center justify-center rounded-lg bg-primary/15 ring-1 ring-primary/40">
        <span className="size-4 rotate-45 rounded-[3px] bg-primary transition-transform duration-300 group-hover:rotate-[135deg]" />
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-sm font-semibold tracking-tight">
          GCC Intelligence AI
        </span>
        <span className="mt-1 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          Enterprise platform
        </span>
      </span>
    </Link>
  );
}
