ALTER TABLE public.processing_jobs
  ADD COLUMN IF NOT EXISTS completed_at timestamptz,
  ADD COLUMN IF NOT EXISTS metadata jsonb NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE public.usage_events
  ADD COLUMN IF NOT EXISTS request_type text,
  ADD COLUMN IF NOT EXISTS conversation_id uuid,
  ADD COLUMN IF NOT EXISTS chunk_count integer NOT NULL DEFAULT 0;

ALTER TABLE public.usage_events
  DROP CONSTRAINT IF EXISTS usage_events_chunk_count_check;
ALTER TABLE public.usage_events
  ADD CONSTRAINT usage_events_chunk_count_check CHECK (chunk_count >= 0);

CREATE OR REPLACE FUNCTION public.check_current_user_rate_limit(_action text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  uid uuid := auth.uid();
  action_limit integer;
  window_seconds integer;
  ws timestamptz;
  current_count integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  CASE _action
    WHEN 'process_document' THEN action_limit := 20; window_seconds := 3600;
    WHEN 'rag_chat' THEN action_limit := 10; window_seconds := 60;
    WHEN 'rag_chat_daily' THEN action_limit := 300; window_seconds := 86400;
    ELSE RAISE EXCEPTION 'Unsupported rate-limit action' USING ERRCODE = '22023';
  END CASE;
  ws := to_timestamp(floor(extract(epoch from now()) / window_seconds) * window_seconds);
  INSERT INTO public.rate_limit_counters (user_id, action, window_start, count)
  VALUES (uid, _action, ws, 1)
  ON CONFLICT (user_id, action, window_start)
  DO UPDATE SET count = public.rate_limit_counters.count + 1
  RETURNING count INTO current_count;
  DELETE FROM public.rate_limit_counters
    WHERE user_id = uid AND action = _action
      AND window_start < now() - make_interval(secs => window_seconds * 2);
  IF current_count > action_limit THEN
    INSERT INTO public.usage_events
      (user_id, event_type, request_type, status, error_code, metadata)
    VALUES
      (uid, 'rate_limit.exceeded', _action, 'rejected', 'rate_limited',
       jsonb_build_object('action', _action, 'limit', action_limit, 'window_seconds', window_seconds));
  END IF;
  RETURN jsonb_build_object(
    'allowed', current_count <= action_limit,
    'count', current_count,
    'limit', action_limit,
    'retry_after_seconds', GREATEST(0, ceil(extract(epoch from (ws + make_interval(secs => window_seconds) - now())))::int)
  );
END;
$function$;
REVOKE ALL ON FUNCTION public.check_current_user_rate_limit(text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.check_current_user_rate_limit(text) TO authenticated;

CREATE OR REPLACE FUNCTION public.log_current_user_usage(
  _event_type text,
  _status text DEFAULT 'ok',
  _document_id uuid DEFAULT NULL,
  _conversation_id uuid DEFAULT NULL,
  _error_code text DEFAULT NULL,
  _error_message text DEFAULT NULL,
  _prompt_tokens integer DEFAULT 0,
  _completion_tokens integer DEFAULT 0,
  _chunk_count integer DEFAULT 0,
  _metadata jsonb DEFAULT '{}'::jsonb)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE uid uuid := auth.uid(); org uuid; new_id uuid; request_name text;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  IF _status NOT IN ('ok','rejected','error') THEN RAISE EXCEPTION 'Invalid usage status' USING ERRCODE = '22023'; END IF;
  IF _event_type NOT IN (
    'process_document.requested','process_document.rejected','process_document.completed','process_document.failed',
    'rag_chat.requested','rag_chat.rejected','rag_chat.completed','rag_chat.failed','rate_limit.exceeded'
  ) THEN RAISE EXCEPTION 'Invalid usage event' USING ERRCODE = '22023'; END IF;
  request_name := split_part(_event_type, '.', 1);
  IF _document_id IS NOT NULL THEN
    SELECT organization_id INTO org FROM public.documents WHERE id = _document_id AND user_id = uid;
    IF NOT FOUND THEN _document_id := NULL; END IF;
  END IF;
  INSERT INTO public.usage_events
    (user_id, organization_id, document_id, conversation_id, event_type, request_type, status,
     error_code, error_message, estimated_prompt_tokens, estimated_completion_tokens, chunk_count, metadata)
  VALUES
    (uid, org, _document_id, _conversation_id, _event_type, request_name, _status,
     _error_code, left(_error_message, 1000), GREATEST(COALESCE(_prompt_tokens,0),0),
     GREATEST(COALESCE(_completion_tokens,0),0), GREATEST(COALESCE(_chunk_count,0),0),
     COALESCE(_metadata,'{}'::jsonb))
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$function$;
REVOKE ALL ON FUNCTION public.log_current_user_usage(text,text,uuid,uuid,text,text,integer,integer,integer,jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_current_user_usage(text,text,uuid,uuid,text,text,integer,integer,integer,jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.claim_current_user_document_processing(_document_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE uid uuid := auth.uid(); doc public.documents%ROWTYPE; job_id uuid; max_bytes bigint; active uuid; ext text;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  SELECT * INTO doc FROM public.documents WHERE id = _document_id AND user_id = uid FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'not_found'); END IF;
  IF doc.file_path !~ ('^' || uid::text || '/' || doc.id::text || '\\.(pdf|txt|csv)$') THEN
    RETURN jsonb_build_object('ok', false, 'code', 'invalid_storage_path');
  END IF;
  ext := lower(substring(doc.file_name from '\.([^.]+)$'));
  IF ext NOT IN ('pdf','txt','csv') OR doc.file_type NOT IN ('application/pdf','text/plain','text/csv','application/csv','application/octet-stream') THEN
    RETURN jsonb_build_object('ok', false, 'code', 'unsupported_type');
  END IF;
  max_bytes := (public.platform_limits() ->> 'max_processing_bytes')::bigint;
  IF doc.file_size <= 0 OR doc.file_size > max_bytes THEN
    RETURN jsonb_build_object('ok', false, 'code', 'too_large_to_process', 'max_processing_bytes', max_bytes);
  END IF;
  SELECT id INTO active FROM public.processing_jobs
    WHERE document_id = _document_id AND status IN ('queued','processing') LIMIT 1;
  IF active IS NOT NULL THEN RETURN jsonb_build_object('ok', false, 'code', 'already_processing', 'job_id', active); END IF;
  BEGIN
    INSERT INTO public.processing_jobs
      (document_id, user_id, organization_id, status, attempt, metadata)
    VALUES
      (_document_id, uid, doc.organization_id, 'queued',
       (SELECT COALESCE(max(attempt),0)+1 FROM public.processing_jobs WHERE document_id = _document_id),
       jsonb_build_object('file_name', doc.file_name, 'file_size', doc.file_size, 'file_type', doc.file_type))
    RETURNING id INTO job_id;
  EXCEPTION WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'code', 'already_processing');
  END;
  UPDATE public.processing_jobs SET status = 'processing', started_at = now() WHERE id = job_id;
  UPDATE public.documents SET status = 'processing', error_message = NULL WHERE id = _document_id;
  RETURN jsonb_build_object('ok', true, 'job_id', job_id);
END;
$function$;
REVOKE ALL ON FUNCTION public.claim_current_user_document_processing(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.claim_current_user_document_processing(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.begin_current_user_chunk_replacement(_document_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.processing_jobs j
    JOIN public.documents d ON d.id = j.document_id
    WHERE j.document_id = _document_id AND j.user_id = uid AND d.user_id = uid AND j.status = 'processing'
  ) THEN RAISE EXCEPTION 'No active owned processing job' USING ERRCODE = '42501'; END IF;
  DELETE FROM public.document_chunks WHERE document_id = _document_id AND user_id = uid;
END;
$function$;
REVOKE ALL ON FUNCTION public.begin_current_user_chunk_replacement(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.begin_current_user_chunk_replacement(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.store_current_user_chunk_batch(_document_id uuid, _chunks jsonb)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE uid uuid := auth.uid(); item jsonb; inserted_count integer := 0; doc public.documents%ROWTYPE;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  IF jsonb_typeof(_chunks) <> 'array' OR jsonb_array_length(_chunks) < 1 OR jsonb_array_length(_chunks) > 50 THEN
    RAISE EXCEPTION 'Chunk batch must contain between 1 and 50 rows' USING ERRCODE = '22023';
  END IF;
  SELECT * INTO doc FROM public.documents WHERE id = _document_id AND user_id = uid;
  IF NOT FOUND OR NOT EXISTS (
    SELECT 1 FROM public.processing_jobs WHERE document_id = _document_id AND user_id = uid AND status = 'processing'
  ) THEN RAISE EXCEPTION 'No active owned processing job' USING ERRCODE = '42501'; END IF;
  FOR item IN SELECT value FROM jsonb_array_elements(_chunks)
  LOOP
    IF btrim(COALESCE(item->>'content','')) = '' THEN RAISE EXCEPTION 'Empty chunks are not allowed' USING ERRCODE = '22023'; END IF;
    IF jsonb_array_length(COALESCE(item->'embedding','[]'::jsonb)) <> 1536 THEN RAISE EXCEPTION 'Embedding must contain 1536 dimensions' USING ERRCODE = '22023'; END IF;
    INSERT INTO public.document_chunks
      (document_id, user_id, organization_id, knowledge_base_id, chunk_index, content, page_number, token_count, embedding)
    VALUES
      (doc.id, uid, doc.organization_id, doc.knowledge_base_id,
       (item->>'chunkIndex')::integer, item->>'content', NULLIF(item->>'pageNumber','')::integer,
       GREATEST(COALESCE((item->>'tokenCount')::integer,0),0), (item->'embedding')::text::extensions.vector(1536));
    inserted_count := inserted_count + 1;
  END LOOP;
  RETURN inserted_count;
END;
$function$;
REVOKE ALL ON FUNCTION public.store_current_user_chunk_batch(uuid,jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.store_current_user_chunk_batch(uuid,jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.finish_current_user_document_processing(
  _job_id uuid, _outcome text, _error_message text DEFAULT NULL, _chunk_count integer DEFAULT 0, _metadata jsonb DEFAULT '{}'::jsonb)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE uid uuid := auth.uid(); job public.processing_jobs%ROWTYPE; new_doc_status public.document_status;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  IF _outcome NOT IN ('completed','failed','cancelled') THEN RAISE EXCEPTION 'Invalid outcome' USING ERRCODE = '22023'; END IF;
  SELECT * INTO job FROM public.processing_jobs
    WHERE id = _job_id AND user_id = uid AND status IN ('queued','processing') FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'job_not_active'); END IF;
  UPDATE public.processing_jobs
    SET status = _outcome::public.processing_job_status,
        finished_at = now(), completed_at = now(), error_message = left(_error_message,1000),
        chunk_count = GREATEST(COALESCE(_chunk_count,0),0), metadata = metadata || COALESCE(_metadata,'{}'::jsonb)
    WHERE id = _job_id;
  new_doc_status := CASE WHEN _outcome = 'completed' THEN 'ready'::public.document_status ELSE 'failed'::public.document_status END;
  UPDATE public.documents
    SET status = new_doc_status,
        error_message = CASE WHEN _outcome = 'completed' THEN NULL ELSE left(_error_message,1000) END
    WHERE id = job.document_id AND user_id = uid;
  RETURN jsonb_build_object('ok', true, 'document_id', job.document_id, 'document_status', new_doc_status, 'chunk_count', GREATEST(COALESCE(_chunk_count,0),0));
END;
$function$;
REVOKE ALL ON FUNCTION public.finish_current_user_document_processing(uuid,text,text,integer,jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.finish_current_user_document_processing(uuid,text,text,integer,jsonb) TO authenticated;

CREATE OR REPLACE FUNCTION public.match_current_user_document_chunks(
  _query_embedding extensions.vector(1536),
  _knowledge_base_id uuid DEFAULT NULL,
  _document_id uuid DEFAULT NULL,
  _similarity_threshold double precision DEFAULT 0,
  _match_count integer DEFAULT 8)
RETURNS TABLE (
  chunk_id uuid, document_id uuid, knowledge_base_id uuid, chunk_index integer, page_number integer,
  content text, file_name text, document_title text, similarity double precision)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
DECLARE uid uuid := auth.uid(); safe_limit integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  IF _knowledge_base_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.knowledge_bases k WHERE k.id = _knowledge_base_id AND k.user_id = uid
  ) THEN RAISE EXCEPTION 'Knowledge base not found' USING ERRCODE = '42501'; END IF;
  IF _document_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM public.documents d WHERE d.id = _document_id AND d.user_id = uid
  ) THEN RAISE EXCEPTION 'Document not found' USING ERRCODE = '42501'; END IF;
  safe_limit := LEAST(GREATEST(COALESCE(_match_count,8),1), (public.platform_limits()->>'max_retrieved_chunks')::integer);
  RETURN QUERY
  SELECT c.id, c.document_id, c.knowledge_base_id, c.chunk_index, c.page_number, c.content,
         d.file_name, d.title,
         1 - (c.embedding OPERATOR(extensions.<=>) _query_embedding) AS similarity
  FROM public.document_chunks c
  JOIN public.documents d ON d.id = c.document_id
  WHERE c.user_id = uid AND d.user_id = uid AND c.embedding IS NOT NULL
    AND (_knowledge_base_id IS NULL OR c.knowledge_base_id = _knowledge_base_id)
    AND (_document_id IS NULL OR c.document_id = _document_id)
    AND 1 - (c.embedding OPERATOR(extensions.<=>) _query_embedding) >= LEAST(GREATEST(COALESCE(_similarity_threshold,0),-1),1)
  ORDER BY c.embedding OPERATOR(extensions.<=>) _query_embedding
  LIMIT safe_limit;
END;
$function$;
REVOKE ALL ON FUNCTION public.match_current_user_document_chunks(extensions.vector,uuid,uuid,double precision,integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.match_current_user_document_chunks(extensions.vector,uuid,uuid,double precision,integer) TO authenticated;

REVOKE ALL ON FUNCTION public.check_rate_limit(uuid,text,integer,integer) FROM service_role;
REVOKE ALL ON FUNCTION public.claim_document_processing(uuid,uuid) FROM service_role;
REVOKE ALL ON FUNCTION public.finish_document_processing(uuid,uuid,text,text,integer) FROM service_role;
REVOKE ALL ON FUNCTION public.log_usage_event(uuid,text,text,uuid,text,text,integer,integer,jsonb) FROM service_role;
REVOKE ALL ON FUNCTION public.match_document_chunks(uuid,extensions.vector,uuid,uuid,integer) FROM service_role;