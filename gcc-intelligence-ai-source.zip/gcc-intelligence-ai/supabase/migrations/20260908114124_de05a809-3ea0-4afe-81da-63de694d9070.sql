DROP FUNCTION public.check_rate_limit(text, integer, integer);
DROP FUNCTION public.log_usage_event(text, text, uuid, text, text, integer, integer, jsonb);
DROP FUNCTION public.claim_document_processing(uuid);
DROP FUNCTION public.finish_document_processing(uuid, text, text);

CREATE OR REPLACE FUNCTION public.check_rate_limit(_user_id uuid, _action text, _limit integer, _window_seconds integer)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE ws timestamptz; current_count integer;
BEGIN
  IF _user_id IS NULL THEN RAISE EXCEPTION 'user id required' USING ERRCODE = '42501'; END IF;
  ws := to_timestamp(floor(extract(epoch from now()) / _window_seconds) * _window_seconds);
  INSERT INTO public.rate_limit_counters (user_id, action, window_start, count)
  VALUES (_user_id, _action, ws, 1)
  ON CONFLICT (user_id, action, window_start) DO UPDATE SET count = public.rate_limit_counters.count + 1
  RETURNING count INTO current_count;
  DELETE FROM public.rate_limit_counters WHERE user_id = _user_id AND action = _action AND window_start < now() - make_interval(secs => _window_seconds * 2);
  IF current_count > _limit THEN
    INSERT INTO public.usage_events (user_id, event_type, status, error_code, metadata)
    VALUES (_user_id, 'rate_limit.exceeded', 'rejected', 'rate_limited', jsonb_build_object('action', _action, 'limit', _limit, 'window_seconds', _window_seconds));
  END IF;
  RETURN jsonb_build_object('allowed', current_count <= _limit, 'count', current_count, 'limit', _limit,
    'retry_after_seconds', GREATEST(0, ceil(extract(epoch from (ws + make_interval(secs => _window_seconds) - now())))::int));
END;
$$;
REVOKE EXECUTE ON FUNCTION public.check_rate_limit(uuid, text, integer, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.check_rate_limit(uuid, text, integer, integer) TO service_role;

CREATE OR REPLACE FUNCTION public.log_usage_event(
  _user_id uuid, _event_type text, _status text DEFAULT 'ok', _document_id uuid DEFAULT NULL,
  _error_code text DEFAULT NULL, _error_message text DEFAULT NULL,
  _prompt_tokens integer DEFAULT 0, _completion_tokens integer DEFAULT 0, _metadata jsonb DEFAULT '{}'::jsonb)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE org uuid; new_id uuid;
BEGIN
  IF _user_id IS NULL THEN RAISE EXCEPTION 'user id required' USING ERRCODE = '42501'; END IF;
  IF _document_id IS NOT NULL THEN
    SELECT organization_id INTO org FROM public.documents WHERE id = _document_id AND user_id = _user_id;
    IF NOT FOUND THEN _document_id := NULL; END IF;
  END IF;
  INSERT INTO public.usage_events (user_id, organization_id, document_id, event_type, status, error_code, error_message, estimated_prompt_tokens, estimated_completion_tokens, metadata)
  VALUES (_user_id, org, _document_id, _event_type, _status, _error_code, left(_error_message, 1000), COALESCE(_prompt_tokens,0), COALESCE(_completion_tokens,0), COALESCE(_metadata,'{}'::jsonb))
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.log_usage_event(uuid, text, text, uuid, text, text, integer, integer, jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.log_usage_event(uuid, text, text, uuid, text, text, integer, integer, jsonb) TO service_role;

CREATE OR REPLACE FUNCTION public.claim_document_processing(_user_id uuid, _document_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE doc public.documents%ROWTYPE; job_id uuid; max_bytes bigint; active uuid;
BEGIN
  IF _user_id IS NULL THEN RAISE EXCEPTION 'user id required' USING ERRCODE = '42501'; END IF;
  SELECT * INTO doc FROM public.documents WHERE id = _document_id AND user_id = _user_id FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'not_found'); END IF;
  max_bytes := (public.platform_limits() ->> 'max_processing_bytes')::bigint;
  IF doc.file_size > max_bytes THEN
    RETURN jsonb_build_object('ok', false, 'code', 'too_large_to_process', 'max_processing_bytes', max_bytes);
  END IF;
  SELECT id INTO active FROM public.processing_jobs WHERE document_id = _document_id AND status IN ('queued','processing') LIMIT 1;
  IF active IS NOT NULL THEN RETURN jsonb_build_object('ok', false, 'code', 'already_processing', 'job_id', active); END IF;
  BEGIN
    INSERT INTO public.processing_jobs (document_id, user_id, organization_id, status, started_at, attempt)
    VALUES (_document_id, _user_id, doc.organization_id, 'processing', now(),
      (SELECT COALESCE(max(attempt),0)+1 FROM public.processing_jobs WHERE document_id = _document_id))
    RETURNING id INTO job_id;
  EXCEPTION WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'code', 'already_processing');
  END;
  UPDATE public.documents SET status = 'processing', error_message = NULL WHERE id = _document_id;
  RETURN jsonb_build_object('ok', true, 'job_id', job_id);
END;
$$;
REVOKE EXECUTE ON FUNCTION public.claim_document_processing(uuid, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.claim_document_processing(uuid, uuid) TO service_role;

CREATE OR REPLACE FUNCTION public.finish_document_processing(_user_id uuid, _job_id uuid, _outcome text, _error_message text DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE job public.processing_jobs%ROWTYPE; new_doc_status public.document_status;
BEGIN
  IF _user_id IS NULL THEN RAISE EXCEPTION 'user id required' USING ERRCODE = '42501'; END IF;
  IF _outcome NOT IN ('completed','failed','cancelled') THEN RAISE EXCEPTION 'Invalid outcome'; END IF;
  SELECT * INTO job FROM public.processing_jobs WHERE id = _job_id AND user_id = _user_id AND status IN ('queued','processing') FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'job_not_active'); END IF;
  UPDATE public.processing_jobs SET status = _outcome::public.processing_job_status, finished_at = now(), error_message = left(_error_message, 1000) WHERE id = _job_id;
  new_doc_status := CASE _outcome WHEN 'completed' THEN 'ready' WHEN 'failed' THEN 'failed' ELSE 'ready' END;
  UPDATE public.documents SET status = new_doc_status, error_message = CASE WHEN _outcome = 'failed' THEN left(_error_message, 1000) ELSE NULL END WHERE id = job.document_id;
  RETURN jsonb_build_object('ok', true, 'document_id', job.document_id, 'document_status', new_doc_status);
END;
$$;
REVOKE EXECUTE ON FUNCTION public.finish_document_processing(uuid, uuid, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.finish_document_processing(uuid, uuid, text, text) TO service_role;