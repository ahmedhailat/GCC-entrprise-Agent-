CREATE SCHEMA IF NOT EXISTS extensions;
GRANT USAGE ON SCHEMA extensions TO anon, authenticated, service_role;
ALTER EXTENSION vector SET SCHEMA extensions;

CREATE OR REPLACE FUNCTION public.match_document_chunks(
  _user_id uuid,
  _query_embedding extensions.vector(1536),
  _knowledge_base_id uuid DEFAULT NULL,
  _document_id uuid DEFAULT NULL,
  _match_count integer DEFAULT 8
)
RETURNS TABLE (
  chunk_id uuid,
  document_id uuid,
  knowledge_base_id uuid,
  chunk_index integer,
  page_number integer,
  content text,
  file_name text,
  document_title text,
  similarity double precision
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public', 'extensions'
AS $function$
  SELECT c.id, c.document_id, c.knowledge_base_id, c.chunk_index, c.page_number, c.content,
         d.file_name, d.title,
         1 - (c.embedding OPERATOR(extensions.<=>) _query_embedding) AS similarity
  FROM public.document_chunks c
  JOIN public.documents d ON d.id = c.document_id
  WHERE c.user_id = _user_id
    AND d.user_id = _user_id
    AND c.embedding IS NOT NULL
    AND (_knowledge_base_id IS NULL OR c.knowledge_base_id = _knowledge_base_id)
    AND (_document_id IS NULL OR c.document_id = _document_id)
  ORDER BY c.embedding OPERATOR(extensions.<=>) _query_embedding
  LIMIT LEAST(GREATEST(COALESCE(_match_count, 8), 1),
              (public.platform_limits() ->> 'max_retrieved_chunks')::int);
$function$;

REVOKE ALL ON FUNCTION public.match_document_chunks(uuid, extensions.vector, uuid, uuid, integer) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.match_document_chunks(uuid, extensions.vector, uuid, uuid, integer) TO service_role;