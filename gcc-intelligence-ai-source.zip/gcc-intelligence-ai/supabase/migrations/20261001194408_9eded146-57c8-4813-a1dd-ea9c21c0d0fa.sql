CREATE OR REPLACE FUNCTION public.claim_current_user_document_processing(_document_id uuid)
 RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE uid uuid := auth.uid(); doc public.documents%ROWTYPE; job_id uuid; max_bytes bigint; active uuid; ext text;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  SELECT * INTO doc FROM public.documents WHERE id = _document_id AND user_id = uid FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'not_found'); END IF;
  IF doc.file_path IS DISTINCT FROM (uid::text || '/' || doc.id::text || '.' || lower(substring(doc.file_path from '\.([^.]+)$')))
     OR lower(substring(doc.file_path from '\.([^.]+)$')) NOT IN ('pdf','txt','csv') THEN
    RETURN jsonb_build_object('ok', false, 'code', 'invalid_storage_path');
  END IF;
  ext := lower(substring(doc.file_name from '\.([^.]+)$'));
  IF ext NOT IN ('pdf','txt','csv') OR doc.file_type NOT IN ('application/pdf','text/plain','text/csv','application/csv','application/octet-stream') THEN
    RETURN jsonb_build_object('ok', false, 'code', 'unsupported_type');
  END IF;
  max_bytes := (public.platform_limits() ->> 'max_processing_bytes')::bigint;
  IF doc.file_size <= 0 OR doc.file_size > max_bytes THEN
    RETURN jsonb_build_object('ok', false, 'code', 'too_large_to_process', 'max_processing_bytes', max_bytes);
  END IF;
  SELECT id INTO active FROM public.processing_jobs
    WHERE document_id = _document_id AND status IN ('queued','processing') LIMIT 1;
  IF active IS NOT NULL THEN RETURN jsonb_build_object('ok', false, 'code', 'already_processing', 'job_id', active); END IF;
  BEGIN
    INSERT INTO public.processing_jobs (document_id, user_id, organization_id, status, attempt, metadata)
    VALUES (_document_id, uid, doc.organization_id, 'queued',
       (SELECT COALESCE(max(attempt),0)+1 FROM public.processing_jobs WHERE document_id = _document_id),
       jsonb_build_object('file_name', doc.file_name, 'file_size', doc.file_size, 'file_type', doc.file_type))
    RETURNING id INTO job_id;
  EXCEPTION WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'code', 'already_processing');
  END;
  UPDATE public.processing_jobs SET status = 'processing', started_at = now() WHERE id = job_id;
  UPDATE public.documents SET status = 'processing', error_message = NULL WHERE id = _document_id;
  RETURN jsonb_build_object('ok', true, 'job_id', job_id);
END;
$function$;