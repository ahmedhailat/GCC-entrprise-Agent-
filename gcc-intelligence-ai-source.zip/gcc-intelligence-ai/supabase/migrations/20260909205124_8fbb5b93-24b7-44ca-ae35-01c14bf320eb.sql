CREATE EXTENSION IF NOT EXISTS vector;

ALTER TABLE public.document_chunks
  ADD COLUMN IF NOT EXISTS knowledge_base_id uuid REFERENCES public.knowledge_bases(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS page_number integer,
  ADD COLUMN IF NOT EXISTS embedding vector(1536);

CREATE INDEX IF NOT EXISTS document_chunks_embedding_idx
  ON public.document_chunks USING hnsw (embedding vector_cosine_ops);

CREATE INDEX IF NOT EXISTS document_chunks_document_idx ON public.document_chunks (document_id, chunk_index);
CREATE INDEX IF NOT EXISTS document_chunks_kb_idx ON public.document_chunks (knowledge_base_id);

ALTER TABLE public.processing_jobs
  ADD COLUMN IF NOT EXISTS chunk_count integer NOT NULL DEFAULT 0;

-- Keep chunk ownership metadata (incl. knowledge base) derived from the parent document.
CREATE OR REPLACE FUNCTION public.enforce_chunk_limits()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE doc_owner uuid; doc_org uuid; doc_kb uuid; existing integer; max_chunks integer;
BEGIN
  SELECT user_id, organization_id, knowledge_base_id INTO doc_owner, doc_org, doc_kb
    FROM public.documents WHERE id = NEW.document_id;
  IF doc_owner IS NULL THEN RAISE EXCEPTION 'Document not found' USING ERRCODE = '23503'; END IF;
  NEW.user_id := doc_owner;
  NEW.organization_id := doc_org;
  NEW.knowledge_base_id := doc_kb;
  IF NEW.content IS NULL OR btrim(NEW.content) = '' THEN
    RAISE EXCEPTION 'Empty chunks are not allowed' USING ERRCODE = 'P0001';
  END IF;
  max_chunks := (public.platform_limits() ->> 'max_chunks_per_document')::int;
  SELECT count(*) INTO existing FROM public.document_chunks WHERE document_id = NEW.document_id;
  IF existing >= max_chunks THEN
    RAISE EXCEPTION 'Chunk limit of % per document reached', max_chunks USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END;
$function$;

-- Finish a processing job, now also recording how many chunks were produced.
CREATE OR REPLACE FUNCTION public.finish_document_processing(
  _user_id uuid, _job_id uuid, _outcome text,
  _error_message text DEFAULT NULL::text, _chunk_count integer DEFAULT NULL::integer)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE job public.processing_jobs%ROWTYPE; new_doc_status public.document_status;
BEGIN
  IF _user_id IS NULL THEN RAISE EXCEPTION 'user id required' USING ERRCODE = '42501'; END IF;
  IF _outcome NOT IN ('completed','failed','cancelled') THEN RAISE EXCEPTION 'Invalid outcome'; END IF;
  SELECT * INTO job FROM public.processing_jobs WHERE id = _job_id AND user_id = _user_id AND status IN ('queued','processing') FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'job_not_active'); END IF;
  UPDATE public.processing_jobs
     SET status = _outcome::public.processing_job_status,
         finished_at = now(),
         error_message = left(_error_message, 1000),
         chunk_count = COALESCE(_chunk_count, chunk_count)
   WHERE id = _job_id;
  new_doc_status := CASE _outcome WHEN 'completed' THEN 'ready' WHEN 'failed' THEN 'failed' ELSE 'ready' END;
  UPDATE public.documents SET status = new_doc_status, error_message = CASE WHEN _outcome = 'failed' THEN left(_error_message, 1000) ELSE NULL END WHERE id = job.document_id;
  RETURN jsonb_build_object('ok', true, 'document_id', job.document_id, 'document_status', new_doc_status, 'chunk_count', COALESCE(_chunk_count, job.chunk_count));
END;
$function$;

-- Owner-scoped vector similarity search. Service-role only; the caller's identity is
-- passed in by the server after `requireSupabaseAuth` has verified it.
CREATE OR REPLACE FUNCTION public.match_document_chunks(
  _user_id uuid,
  _query_embedding vector(1536),
  _knowledge_base_id uuid DEFAULT NULL,
  _document_id uuid DEFAULT NULL,
  _match_count integer DEFAULT 8
)
RETURNS TABLE (
  chunk_id uuid,
  document_id uuid,
  knowledge_base_id uuid,
  chunk_index integer,
  page_number integer,
  content text,
  file_name text,
  document_title text,
  similarity double precision
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT c.id, c.document_id, c.knowledge_base_id, c.chunk_index, c.page_number, c.content,
         d.file_name, d.title,
         1 - (c.embedding <=> _query_embedding) AS similarity
  FROM public.document_chunks c
  JOIN public.documents d ON d.id = c.document_id
  WHERE c.user_id = _user_id
    AND d.user_id = _user_id
    AND c.embedding IS NOT NULL
    AND (_knowledge_base_id IS NULL OR c.knowledge_base_id = _knowledge_base_id)
    AND (_document_id IS NULL OR c.document_id = _document_id)
  ORDER BY c.embedding <=> _query_embedding
  LIMIT LEAST(GREATEST(COALESCE(_match_count, 8), 1),
              (public.platform_limits() ->> 'max_retrieved_chunks')::int);
$function$;

REVOKE ALL ON FUNCTION public.match_document_chunks(uuid, vector, uuid, uuid, integer) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.match_document_chunks(uuid, vector, uuid, uuid, integer) TO service_role;
REVOKE ALL ON FUNCTION public.finish_document_processing(uuid, uuid, text, text, integer) FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.finish_document_processing(uuid, uuid, text, text, integer) TO service_role;