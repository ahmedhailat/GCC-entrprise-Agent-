-- ============================================================
-- 1. Server-side validation on documents (type, size, KB ownership)
-- ============================================================
ALTER TABLE public.documents
  ADD CONSTRAINT documents_file_size_limit CHECK (file_size > 0 AND file_size <= 26214400);

ALTER TABLE public.documents
  ADD CONSTRAINT documents_file_type_allowed CHECK (
    file_type IN (
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/csv',
      'application/csv',
      'text/plain',
      'application/octet-stream'
    )
  );

-- A document may only be attached to a knowledge base owned by the same user/org.
CREATE OR REPLACE FUNCTION public.enforce_document_kb_ownership()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE kb_owner uuid; kb_org uuid;
BEGIN
  IF NEW.knowledge_base_id IS NULL THEN RETURN NEW; END IF;
  SELECT user_id, organization_id INTO kb_owner, kb_org FROM public.knowledge_bases WHERE id = NEW.knowledge_base_id;
  IF kb_owner IS NULL THEN
    RAISE EXCEPTION 'Knowledge base not found' USING ERRCODE = '23503';
  END IF;
  IF kb_owner <> NEW.user_id OR kb_org IS DISTINCT FROM NEW.organization_id THEN
    RAISE EXCEPTION 'You cannot assign a document to a knowledge base you do not own' USING ERRCODE = '42501';
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.enforce_document_kb_ownership() FROM PUBLIC, anon, authenticated;

CREATE TRIGGER documents_enforce_kb_ownership
BEFORE INSERT OR UPDATE OF knowledge_base_id, user_id, organization_id ON public.documents
FOR EACH ROW EXECUTE FUNCTION public.enforce_document_kb_ownership();

-- ============================================================
-- 2. Platform limits: single source of truth
-- ============================================================
CREATE OR REPLACE FUNCTION public.platform_limits()
RETURNS jsonb
LANGUAGE sql
IMMUTABLE
SET search_path = public
AS $$
  SELECT jsonb_build_object(
    'max_upload_bytes',            26214400,   -- 25 MB (matches bucket + CHECK)
    'max_processing_bytes',        10485760,   -- 10 MB may be sent for processing
    'max_chunks_per_document',     500,
    'max_retrieved_chunks',        8,
    'process_document_per_hour',   20,
    'rag_chat_per_minute',         10,
    'rag_chat_per_day',            300,
    'max_chat_message_chars',      4000
  );
$$;
GRANT EXECUTE ON FUNCTION public.platform_limits() TO authenticated, service_role;

-- ============================================================
-- 3. document_chunks (prepared; no embeddings/vector columns)
-- ============================================================
CREATE TABLE public.document_chunks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id uuid,
  chunk_index integer NOT NULL CHECK (chunk_index >= 0 AND chunk_index < 500),
  content text NOT NULL CHECK (length(content) <= 20000),
  token_count integer NOT NULL DEFAULT 0 CHECK (token_count >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (document_id, chunk_index)
);
CREATE INDEX document_chunks_document_id_idx ON public.document_chunks (document_id);
CREATE INDEX document_chunks_user_id_idx ON public.document_chunks (user_id);

GRANT SELECT ON public.document_chunks TO authenticated;
GRANT ALL ON public.document_chunks TO service_role;

ALTER TABLE public.document_chunks ENABLE ROW LEVEL SECURITY;
-- Read-only for owners. No INSERT/UPDATE/DELETE policies: clients cannot write chunks.
CREATE POLICY "Users can view chunks of their own documents"
  ON public.document_chunks FOR SELECT TO authenticated
  USING (auth.uid() = user_id AND EXISTS (SELECT 1 FROM public.documents d WHERE d.id = document_id AND d.user_id = auth.uid()));

-- Hard cap + owner consistency, enforced even for service_role writers.
CREATE OR REPLACE FUNCTION public.enforce_chunk_limits()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE doc_owner uuid; doc_org uuid; existing integer; max_chunks integer;
BEGIN
  SELECT user_id, organization_id INTO doc_owner, doc_org FROM public.documents WHERE id = NEW.document_id;
  IF doc_owner IS NULL THEN RAISE EXCEPTION 'Document not found' USING ERRCODE = '23503'; END IF;
  NEW.user_id := doc_owner;
  NEW.organization_id := doc_org;
  max_chunks := (public.platform_limits() ->> 'max_chunks_per_document')::int;
  SELECT count(*) INTO existing FROM public.document_chunks WHERE document_id = NEW.document_id;
  IF existing >= max_chunks THEN
    RAISE EXCEPTION 'Chunk limit of % per document reached', max_chunks USING ERRCODE = 'P0001';
  END IF;
  RETURN NEW;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.enforce_chunk_limits() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER document_chunks_enforce_limits
BEFORE INSERT ON public.document_chunks FOR EACH ROW EXECUTE FUNCTION public.enforce_chunk_limits();

-- ============================================================
-- 4. processing_jobs: DB-backed lock / idempotency
-- ============================================================
CREATE TYPE public.processing_job_status AS ENUM ('queued', 'processing', 'completed', 'failed', 'cancelled');

CREATE TABLE public.processing_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id uuid,
  status public.processing_job_status NOT NULL DEFAULT 'queued',
  attempt integer NOT NULL DEFAULT 1,
  error_message text,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
-- Only one active job per document at any time.
CREATE UNIQUE INDEX processing_jobs_one_active_per_document
  ON public.processing_jobs (document_id) WHERE status IN ('queued', 'processing');
CREATE INDEX processing_jobs_user_id_idx ON public.processing_jobs (user_id);

GRANT SELECT ON public.processing_jobs TO authenticated;
GRANT ALL ON public.processing_jobs TO service_role;
ALTER TABLE public.processing_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own processing jobs"
  ON public.processing_jobs FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE TRIGGER update_processing_jobs_updated_at BEFORE UPDATE ON public.processing_jobs
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================================
-- 5. usage_events: append-only audit log
-- ============================================================
CREATE TABLE public.usage_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  organization_id uuid,
  document_id uuid REFERENCES public.documents(id) ON DELETE SET NULL,
  event_type text NOT NULL CHECK (event_type IN (
    'process_document.requested','process_document.rejected','process_document.completed','process_document.failed',
    'rag_chat.requested','rag_chat.rejected','rag_chat.completed','rag_chat.failed',
    'rate_limit.exceeded'
  )),
  status text NOT NULL DEFAULT 'ok' CHECK (status IN ('ok','rejected','error')),
  error_code text,
  error_message text,
  estimated_prompt_tokens integer NOT NULL DEFAULT 0 CHECK (estimated_prompt_tokens >= 0),
  estimated_completion_tokens integer NOT NULL DEFAULT 0 CHECK (estimated_completion_tokens >= 0),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX usage_events_user_created_idx ON public.usage_events (user_id, created_at DESC);
CREATE INDEX usage_events_document_idx ON public.usage_events (document_id);

GRANT SELECT ON public.usage_events TO authenticated;
GRANT ALL ON public.usage_events TO service_role;
ALTER TABLE public.usage_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their own usage events"
  ON public.usage_events FOR SELECT TO authenticated USING (auth.uid() = user_id);
-- No update/delete for anyone through the API: immutable audit trail.
CREATE OR REPLACE FUNCTION public.prevent_usage_event_mutation()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN RAISE EXCEPTION 'usage_events is append-only' USING ERRCODE = '42501'; END; $$;
CREATE TRIGGER usage_events_immutable BEFORE UPDATE OR DELETE ON public.usage_events
FOR EACH ROW EXECUTE FUNCTION public.prevent_usage_event_mutation();

-- ============================================================
-- 6. rate_limit_counters (fixed windows, atomic upsert)
-- ============================================================
CREATE TABLE public.rate_limit_counters (
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  action text NOT NULL,
  window_start timestamptz NOT NULL,
  count integer NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, action, window_start)
);
GRANT ALL ON public.rate_limit_counters TO service_role;
ALTER TABLE public.rate_limit_counters ENABLE ROW LEVEL SECURITY;
-- No policies: not readable or writable by clients; only security-definer functions touch it.

-- ============================================================
-- 7. Backend functions (SECURITY DEFINER, act on auth.uid())
-- ============================================================
CREATE OR REPLACE FUNCTION public.check_rate_limit(_action text, _limit integer, _window_seconds integer)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE uid uuid := auth.uid(); ws timestamptz; current_count integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  ws := to_timestamp(floor(extract(epoch from now()) / _window_seconds) * _window_seconds);
  INSERT INTO public.rate_limit_counters (user_id, action, window_start, count)
  VALUES (uid, _action, ws, 1)
  ON CONFLICT (user_id, action, window_start) DO UPDATE SET count = public.rate_limit_counters.count + 1
  RETURNING count INTO current_count;
  -- opportunistic cleanup of old windows
  DELETE FROM public.rate_limit_counters WHERE user_id = uid AND action = _action AND window_start < now() - make_interval(secs => _window_seconds * 2);
  IF current_count > _limit THEN
    INSERT INTO public.usage_events (user_id, event_type, status, error_code, metadata)
    VALUES (uid, 'rate_limit.exceeded', 'rejected', 'rate_limited', jsonb_build_object('action', _action, 'limit', _limit, 'window_seconds', _window_seconds));
  END IF;
  RETURN jsonb_build_object('allowed', current_count <= _limit, 'count', current_count, 'limit', _limit, 'retry_after_seconds', GREATEST(0, ceil(extract(epoch from (ws + make_interval(secs => _window_seconds) - now())))::int));
END;
$$;
REVOKE EXECUTE ON FUNCTION public.check_rate_limit(text, integer, integer) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.check_rate_limit(text, integer, integer) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.log_usage_event(
  _event_type text, _status text DEFAULT 'ok', _document_id uuid DEFAULT NULL,
  _error_code text DEFAULT NULL, _error_message text DEFAULT NULL,
  _prompt_tokens integer DEFAULT 0, _completion_tokens integer DEFAULT 0, _metadata jsonb DEFAULT '{}'::jsonb)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE uid uuid := auth.uid(); org uuid; new_id uuid;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  IF _document_id IS NOT NULL THEN
    SELECT organization_id INTO org FROM public.documents WHERE id = _document_id AND user_id = uid;
    IF NOT FOUND THEN _document_id := NULL; END IF;  -- never log foreign document ids
  END IF;
  INSERT INTO public.usage_events (user_id, organization_id, document_id, event_type, status, error_code, error_message, estimated_prompt_tokens, estimated_completion_tokens, metadata)
  VALUES (uid, org, _document_id, _event_type, _status, _error_code, left(_error_message, 1000), COALESCE(_prompt_tokens,0), COALESCE(_completion_tokens,0), COALESCE(_metadata,'{}'::jsonb))
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.log_usage_event(text, text, uuid, text, text, integer, integer, jsonb) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.log_usage_event(text, text, uuid, text, text, integer, integer, jsonb) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.claim_document_processing(_document_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE uid uuid := auth.uid(); doc public.documents%ROWTYPE; job_id uuid; max_bytes bigint; active uuid;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  -- Authoritative ownership check (user + org must match the caller's row).
  SELECT * INTO doc FROM public.documents WHERE id = _document_id AND user_id = uid FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'code', 'not_found');
  END IF;
  max_bytes := (public.platform_limits() ->> 'max_processing_bytes')::bigint;
  IF doc.file_size > max_bytes THEN
    RETURN jsonb_build_object('ok', false, 'code', 'too_large_to_process', 'max_processing_bytes', max_bytes);
  END IF;
  SELECT id INTO active FROM public.processing_jobs WHERE document_id = _document_id AND status IN ('queued','processing') LIMIT 1;
  IF active IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false, 'code', 'already_processing', 'job_id', active);
  END IF;
  BEGIN
    INSERT INTO public.processing_jobs (document_id, user_id, organization_id, status, started_at,
      attempt)
    VALUES (_document_id, uid, doc.organization_id, 'processing', now(),
      (SELECT COALESCE(max(attempt),0)+1 FROM public.processing_jobs WHERE document_id = _document_id))
    RETURNING id INTO job_id;
  EXCEPTION WHEN unique_violation THEN
    RETURN jsonb_build_object('ok', false, 'code', 'already_processing');
  END;
  UPDATE public.documents SET status = 'processing', error_message = NULL WHERE id = _document_id;
  RETURN jsonb_build_object('ok', true, 'job_id', job_id);
END;
$$;
REVOKE EXECUTE ON FUNCTION public.claim_document_processing(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.claim_document_processing(uuid) TO authenticated, service_role;

CREATE OR REPLACE FUNCTION public.finish_document_processing(_job_id uuid, _outcome text, _error_message text DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE uid uuid := auth.uid(); job public.processing_jobs%ROWTYPE; new_doc_status public.document_status;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '42501'; END IF;
  IF _outcome NOT IN ('completed','failed','cancelled') THEN RAISE EXCEPTION 'Invalid outcome'; END IF;
  SELECT * INTO job FROM public.processing_jobs WHERE id = _job_id AND user_id = uid AND status IN ('queued','processing') FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false, 'code', 'job_not_active'); END IF;
  UPDATE public.processing_jobs SET status = _outcome::public.processing_job_status, finished_at = now(), error_message = left(_error_message, 1000) WHERE id = _job_id;
  new_doc_status := CASE _outcome WHEN 'completed' THEN 'ready' WHEN 'failed' THEN 'failed' ELSE 'ready' END;
  UPDATE public.documents SET status = new_doc_status, error_message = CASE WHEN _outcome = 'failed' THEN left(_error_message, 1000) ELSE NULL END WHERE id = job.document_id;
  RETURN jsonb_build_object('ok', true, 'document_id', job.document_id, 'document_status', new_doc_status);
END;
$$;
REVOKE EXECUTE ON FUNCTION public.finish_document_processing(uuid, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.finish_document_processing(uuid, text, text) TO authenticated, service_role;