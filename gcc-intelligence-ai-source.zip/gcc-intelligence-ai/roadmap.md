# Phase 3 verification roadmap

- [x] Inspect current backend schema, policies, storage, and AI implementation
- [x] Complete processing, retrieval, RAG, citations, and usage logging
- [x] Apply required database migrations (storage-path check fixed)
- [x] Type safety check
- [x] Authenticated PDF upload through the app
- [ ] Embeddings, vector search, RAG answer, negative test — BLOCKED: OpenAI account has no credits
- [x] Unauthenticated rejection and usage logging checks
