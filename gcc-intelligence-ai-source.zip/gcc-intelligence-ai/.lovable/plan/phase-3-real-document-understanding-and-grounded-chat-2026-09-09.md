# Phase 3 — Real document understanding and grounded chat

Turns the existing document library into a working intelligence layer: uploaded files are read,
split into passages, indexed for meaning-based search, and used to answer questions with citations
back to the source document. No page redesign — the current dashboard, documents, knowledge bases,
profile and sign-in flows stay exactly as they are.

## Important: your key was pasted in chat

The OpenAI key you sent is now visible in this conversation's history. I will store it securely so it
never appears in the app's code, but you should **create a replacement key in your OpenAI account and
delete the pasted one** afterwards. Send me the new one and I'll swap it in.

## What gets built

1. **Passage store with meaning search** — the passage table gains the fields for knowledge base,
   page number and a 1536-dimension meaning vector, plus a similarity index.
2. **Reading files** — real text extraction for PDF, TXT and CSV. Word and Excel files stay
   uploadable but are clearly marked as not yet processable. Extraction failure gives a real error,
   never invented text.
3. **Splitting** — deterministic passages with overlap, keeping document, knowledge base and page
   number; empty passages rejected; existing 500-passage cap enforced.
4. **Indexing** — server-side call to OpenAI `text-embedding-3-small` (1536 dims), batched.
5. **Job lifecycle** — queued → processing → completed/failed with timestamps, error message and
   passage count; the existing one-job-per-document lock is reused.
6. **Search function** — a database function that checks the caller owns the data and returns
   passage text, document id, passage id, page number, similarity score and file name.
7. **Grounded chat** — a real answer flow using `gpt-4o-mini` over the retrieved passages, with a
   strict instruction to answer only from them, otherwise reply
   "I could not find sufficient information in the available knowledge base."
8. **Usage records** — user, organization, request type, tokens, passage count and status recorded
   for every request, including failures.
9. **Verification** — real end-to-end run: upload a PDF/TXT/CSV, process it, search it, ask a
   question, and report the evidence table you asked for.

## UI touch (minimal, additive only)

A "Process" action and live status on the existing document detail page, and wiring the existing
Conversations page to the real chat endpoint. No layout or styling changes.

## Technical notes

- Secret `OPENAI_API_KEY` stored in backend secrets, read only inside server handlers.
- Migration: `create extension vector`; add `knowledge_base_id`, `page_number`,
  `embedding vector(1536)` to `document_chunks`; hnsw cosine index; keep owner-only RLS with no
  client write policies. Add `chunk_count` to `processing_jobs`.
- `match_document_chunks(_user_id, _query_embedding, _knowledge_base_id, _document_id, _match_count)`
  as SECURITY DEFINER, service-role only, filtering by owner and capped at the existing 8-chunk max.
- Extraction: `unpdf` (Worker-compatible, pure JS) for PDF; native decoding for TXT/CSV.
  `pdf-parse` is Node-only and will not run on the edge runtime.
- New server-only modules under `src/lib/ai/`: `extract.server.ts`, `chunk.ts`, `openai.server.ts`,
  `retrieval.server.ts`; `ai.functions.ts` gains the real `processDocument` and `ragChat` bodies,
  keeping the current auth middleware, Zod validation, rate limits and audit calls untouched.
- Embedding and chat calls go to OpenAI directly with your key, per your instruction.
